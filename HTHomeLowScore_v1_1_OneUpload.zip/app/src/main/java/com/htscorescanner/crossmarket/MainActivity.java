package com.htscorescanner.crossmarket;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Color;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int CREATE_DOCUMENT_REQUEST = 7331;
    private WebView webView;
    private AIRequestBridge aiRequestBridge;
    private byte[] pendingBytes;
    private final ExecutorService saveExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10,16,32));
        getWindow().setNavigationBarColor(Color.rgb(10,16,32));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(10,16,32));
        setContentView(webView);
        // Native WebView alert/confirm support is retained for general app messages.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                                        .setMessage(message)
                    .setPositiveButton("继续", (dialog, which) -> result.confirm())
                    .setNegativeButton("取消", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton("确定", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.confirm())
                    .show();
                return true;
            }
        });

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true); // remember API Key in app-private WebView storage
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setSupportMultipleWindows(false);

        // Serve the packaged HTML on a trustworthy HTTPS origin; avoid file:// CORS issues.
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .setDomain(APP_HOST)
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target=request.getUrl();
                if ("https".equals(target.getScheme()) && APP_HOST.equals(target.getHost())) return false;
                if (!request.isForMainFrame()) return true;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, target));
                } catch (ActivityNotFoundException e) { showToast("无法打开外部链接"); }
                return true;
            }
        });
        // Expose only to our packaged page; no arbitrary remote documents load in the WebView.
        webView.addJavascriptInterface(new FileBridge(), "AndroidFile");
        aiRequestBridge = new AIRequestBridge(webView);
        webView.addJavascriptInterface(aiRequestBridge, "AndroidAI");
        webView.loadUrl(APP_URL);
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    public final class FileBridge {
        @JavascriptInterface public void saveBase64(String fileName, String mimeType, String base64Body) {
            if (base64Body == null || base64Body.length() > 28_000_000) {
                showToast("文件太大，无法保存"); return;
            }
            String sanitized = fileName == null ? "HTScoreScanner.png" : fileName.replaceAll("[^0-9a-zA-Z._() 一-龥-]", "_");
            if (sanitized.isEmpty()) sanitized="HTScoreScanner.png";
            final String name=sanitized;
            final String mime = mimeType != null && mimeType.toLowerCase(Locale.ROOT).startsWith("image/png") ? "image/png"
                : mimeType != null && mimeType.toLowerCase(Locale.ROOT).startsWith("text/csv") ? "text/csv"
                : "application/octet-stream";
            saveExecutor.execute(() -> {
                try {
                    byte[] bytes=Base64.decode(base64Body, Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveMediaStore(name,mime,bytes);
                    else runOnUiThread(() -> selectDocument(name,mime,bytes));
                } catch(Exception e) { showToast("保存失败：" + e.getMessage()); }
            });
        }
    }

    private void saveMediaStore(String name, String mime, byte[] bytes) throws IOException {
        boolean image=mime.startsWith("image/");
        Uri collection=image ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        ContentValues values=new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,(image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS)+"/HTScoreScanner");
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri uri=getContentResolver().insert(collection,values);
        if(uri==null) throw new IOException("未能创建文件");
        try {
            try(OutputStream os=getContentResolver().openOutputStream(uri)) {
                if(os==null) throw new IOException("无法写入文件");
                os.write(bytes);
            }
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,done,null,null);
            showToast(image ? "图片已保存到相册 Pictures/HTScoreScanner" : "文件已保存到 Downloads/HTScoreScanner");
        } catch(IOException e) {
            getContentResolver().delete(uri,null,null);
            throw e;
        }
    }

    // Android 8-9: use system document picker, avoiding broad storage permissions.
    private void selectDocument(String name, String mime, byte[] bytes) {
        pendingBytes=bytes;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE,name);
        try { startActivityForResult(intent,CREATE_DOCUMENT_REQUEST); }
        catch(ActivityNotFoundException e) { pendingBytes=null; showToast("系统没有文件保存程序"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=CREATE_DOCUMENT_REQUEST) return;
        byte[] bytes=pendingBytes; pendingBytes=null;
        Uri uri=data==null?null:data.getData();
        if(resultCode!=RESULT_OK||uri==null||bytes==null) return;
        saveExecutor.execute(() -> {
            try(OutputStream os=getContentResolver().openOutputStream(uri)) {
                if(os==null) throw new IOException("无法创建输出流");
                os.write(bytes); showToast("文件已保存");
            }catch(Exception e){showToast("保存失败："+e.getMessage());}
        });
    }

    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(aiRequestBridge!=null) aiRequestBridge.shutdown();
        if(webView!=null){ webView.removeJavascriptInterface("AndroidFile"); webView.removeJavascriptInterface("AndroidAI"); webView.destroy(); }
        saveExecutor.shutdown();
        super.onDestroy();
    }
}
