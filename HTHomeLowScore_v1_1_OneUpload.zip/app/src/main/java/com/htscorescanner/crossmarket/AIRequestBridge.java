package com.htscorescanner.crossmarket;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Makes HTTPS OpenAI calls on-device, avoiding Android WebView CORS failures.
 *  Keys are supplied only by the local packaged app and are never logged or shipped in source.
 */
public final class AIRequestBridge {
    private static final String ENDPOINT = "https://api.openai.com/v1/chat/completions";
    private final WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean destroyed = false;

    AIRequestBridge(WebView webView) { this.webView = webView; }

    @JavascriptInterface
    public void request(String requestId, String apiKey, String body) {
        if (requestId == null || !requestId.matches("[0-9]{1,12}")) return;
        if (destroyed) return;
        if (apiKey == null || apiKey.trim().isEmpty() || body == null || body.length() > 150000) {
            send(requestId, false, "OpenAI Key 未设置或请求大小超过限制");
            return;
        }
        executor.execute(() -> perform(requestId, apiKey.trim(), body));
    }

    private void perform(String requestId, String apiKey, String body) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(ENDPOINT).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(45000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = connection.getOutputStream()) { os.write(bytes); }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            String result = readLimited(stream);
            if (status >= 200 && status < 300) {
                send(requestId, true, result);
            } else {
                String error = "OpenAI HTTP " + status;
                try {
                    String detail = new JSONObject(result).optJSONObject("error").optString("message", "");
                    if (!detail.isEmpty()) error += ": " + detail;
                } catch (Exception ignored) { /* avoid revealing headers or Key */ }
                send(requestId, false, error);
            }
        } catch (Exception e) {
            send(requestId, false, "OpenAI 网络请求异常：" + e.getClass().getSimpleName());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readLimited(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) {
                if (out.size() + n > 400000) throw new Exception("OpenAI response too large");
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        }
    }

    private void send(String requestId, boolean ok, String text) {
        if (destroyed) return;
        final String script = "window.HTAI&&window.HTAI.onReply(" + JSONObject.quote(requestId)
            + "," + (ok ? "true" : "false") + "," + JSONObject.quote(text) + ");";
        webView.post(() -> {
            if (!destroyed && webView.getUrl() != null &&
                webView.getUrl().startsWith("https://appassets.androidplatform.net/assets/index.html")) {
                webView.evaluateJavascript(script, null);
            }
        });
    }

    void shutdown() { destroyed = true; executor.shutdownNow(); }
}
