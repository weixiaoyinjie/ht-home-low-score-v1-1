
(()=>{'use strict';
const TZ='America/Argentina/Buenos_Aires';
const el=id=>document.getElementById(id);const app={fixtures:[],ranked:[],selected:new Set(),key:'',markets:{},running:false,cancel:false,calls:0,studied:0,riskDropped:0,partial:false,histories:new Map(),expandedHistory:new Set(),standingCache:new Map(),recentToken:0,aiToken:0,reviewBusy:false};
const fmt=(time,options)=>new Intl.DateTimeFormat('zh-CN',{timeZone:TZ,...options}).format(new Date(time));
const hm=time=>fmt(time,{hour:'2-digit',minute:'2-digit',hour12:false});
const ymd=time=>{const p=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(time)); const x=Object.fromEntries(p.map(z=>[z.type,z.value]));return `${x.year}-${x.month}-${x.day}`};
el('day').value=ymd(Date.now());
const out=(msg)=>{el('status').textContent=msg;};
const log=(msg)=>{const n=el('log');if(n.textContent==='尚无日志')n.textContent='';n.textContent+=`[${new Date().toLocaleTimeString('zh-CN',{timeZone:TZ})}] ${msg}\n`;n.scrollTop=n.scrollHeight};
const pct=x=>`${(100*x).toFixed(1)}%`;
const money=x=>Number.isFinite(x)?x.toFixed(2):'—';
const esc=x=>String(x??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const median=a=>{if(!a.length)return 0;let b=[...a].sort((x,y)=>x-y);return b.length%2?b[(b.length-1)/2]:(b[b.length/2-1]+b[b.length/2])/2};
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const sleep=t=>new Promise(r=>setTimeout(r,t));
function renderProgress(frac){el('bar').style.width=`${Math.round(clamp(frac,0,1)*100)}%`}
const KEY_STORE='ht-score-scanner-api-key-v3';
try{const saved=localStorage.getItem(KEY_STORE);if(saved)el('apiKey').value=saved;}catch(e){/* WebView may block localStorage */}
function saveKey(){try{if(el('rememberKey').checked){localStorage.setItem(KEY_STORE,el('apiKey').value.trim());}else localStorage.removeItem(KEY_STORE);}catch(e){log('当前浏览器不允许本机持久保存 Key。')}}
el('apiKey').addEventListener('change',saveKey);
el('rememberKey').addEventListener('change',saveKey);
const OPENAI_KEY_STORE='ht-score-scanner-openai-key-v1';
const OPENAI_MODEL_STORE='ht-score-scanner-openai-model-v1';
try{const savedOpenAI=localStorage.getItem(OPENAI_KEY_STORE);if(savedOpenAI)el('openAiKey').value=savedOpenAI;const savedModel=localStorage.getItem(OPENAI_MODEL_STORE);if(savedModel)el('openAiModel').value=savedModel;}catch(e){/* localStorage optional */}
function saveOpenAIConfig(){try{if(el('rememberOpenAiKey').checked){localStorage.setItem(OPENAI_KEY_STORE,el('openAiKey').value.trim());}else localStorage.removeItem(OPENAI_KEY_STORE);localStorage.setItem(OPENAI_MODEL_STORE,el('openAiModel').value);}catch(e){log('当前浏览器不允许本机持久保存 AI Key。')}}
el('openAiKey').addEventListener('change',saveOpenAIConfig);
el('rememberOpenAiKey').addEventListener('change',saveOpenAIConfig);
el('openAiModel').addEventListener('change',saveOpenAIConfig);
function getOpenAIConfig(requireKey=true){const key=el('openAiKey').value.trim();const model=el('openAiModel').value||'gpt-4.1-mini';saveOpenAIConfig();if(requireKey&&!key)throw Error('请先在“AI 分析设置”里输入 OpenAI API Key。');return {key,model}}
function getKey(){const k=el('apiKey').value.trim();if(!k)throw Error('请输入 API-FOOTBALL Key。');saveKey();return k}
function setRunning(r){app.running=r;el('scan').disabled=r;el('test').disabled=r;el('stop').disabled=!r;el('day').disabled=r;}
async function api(path,params={}){
 if(app.cancel)throw Error('用户已停止扫描');
 const qs=new URLSearchParams(Object.entries(params).filter(([,v])=>v!==null&&v!==undefined).map(([k,v])=>[k,String(v)]));
 const url=`https://v3.football.api-sports.io/${path}${qs.size?'?'+qs:''}`;
 app.calls++;
 let r;try{r=await fetch(url,{headers:{'x-apisports-key':app.key},cache:'no-store'})}catch(e){throw Error('网络请求失败（可能是跨域/CORS、断网或浏览器限制）。可换浏览器或把请求移到后端代理。原错误：'+e.message)}
 const raw=await r.text();let data;try{data=JSON.parse(raw)}catch{throw Error(`接口返回非JSON数据（HTTP ${r.status}）：${raw.slice(0,100)}`)}
 if(!r.ok)throw Error(`API HTTP ${r.status}: ${JSON.stringify(data.errors??data.message??'').slice(0,200)}`);
 if(data.errors && (Array.isArray(data.errors)?data.errors.length:Object.keys(data.errors).length))throw Error(`API 拒绝请求：${JSON.stringify(data.errors).slice(0,250)}`);
 return data;
}
// Preserve the original eight correct-score odds board and all other app features.
// These are research priorities, NOT forced probabilities: history computes the ranks.
const scoreSet=['0-0','1-0','0-1','1-1','2-0','0-2','2-1','1-2','2-2','3-0','0-3','3-1','1-3','3-2','2-3','4-0','0-4'];
const primaryScoreSet=['0-0','1-0'];
const secondaryScoreSet=['2-0','1-1'];
const targetScoreSet=['0-0','1-0','2-0','1-1'];
const referenceSet=['1-0','2-0','0-0','0-1','1-1','2-1','0-2','1-2'];
const MIN_ODD=4, ZERO_MIN_ODD=3;
const qualifiesPrice=(q,minOdd=MIN_ODD,score=null)=>!!q&&q.bet365===true&&Number.isFinite(q.odd)&&
 q.odd>1&&q.odd>=(score==='0-0'?ZERO_MIN_ODD:Math.max(MIN_ODD,minOdd));
const scorePriceOK=(p,minOdd=MIN_ODD)=>!!p&&qualifiesPrice(p.quote,minOdd,p.score);
const estimatedEV=p=>p.quote?.bet365?p.probability*p.quote.odd-1:null;
function scoreRankingProfile(rates,mkt){
 const all=scoreSet.map(score=>({score,prob:scoreProbability(score,rates)})).sort((a,b)=>b.prob-a.prob);
 const rank=s=>all.findIndex(x=>x.score===s)+1;
 const z=scoreProbability('0-0',rates),h=scoreProbability('1-0',rates),two=scoreProbability('2-0',rates),draw=scoreProbability('1-1',rates),away=scoreProbability('0-1',rates);
 const first=z+h,homeLow=first+two,coverage=homeLow+draw,total=rates.lh+rates.la;
 const ht=mkt.ht?.prob||footballOutcome(rates.lh,rates.la);
 const ou15=mkt.htTotals?.find(t=>t.line===1.5),under15=ou15?1-ou15.probOver:null;
 const ou05=mkt.htTotals?.find(t=>t.line===.5),under05=ou05?1-ou05.probOver:null;
 const topTwo=new Set(all.slice(0,2).map(x=>x.score));
 const strictTop=topTwo.has('0-0')&&topTwo.has('1-0');
 const secondaryCount=all.slice(2,4).filter(x=>secondaryScoreSet.includes(x.score)).length;
 const homeBias=ht.home>=ht.away+.07&&rates.lh>rates.la+.17;
 const issues=[];
 if(!strictTop)issues.push(`最高两名为${all.slice(0,2).map(x=>x.score).join('/')}，并非0-0/1-0`);
 if(secondaryCount<2)issues.push(`第3/4名为${all.slice(2,4).map(x=>x.score).join('/')}，2-0/1-1未同时进入次选组`);
 if(first<.41||coverage<.61)issues.push(`0-0+1-0仅${pct(first)}、四比分共${pct(coverage)}，集中度不足`);
 if(total>1.80||total<.75)issues.push(`半场预期总进球${money(total)}，不符合当前可研究区间`);
 if(!homeBias)issues.push('主队半场优势不明显，或客队不败/进球风险偏高');
 if(away>.15||ht.away>.29)issues.push(`客队0-1概率${pct(away)}或半场客胜风险偏高`);
 if(under15!==null&&under15<.49)issues.push('半场小1.5市场概率不足49%');
 if(under05!==null&&Math.abs(under05-z)>.17)issues.push('0-0历史概率与半场小0.5赔率明显冲突');
 return {all,rank,strictTop,secondaryCount,first,homeLow,coverage,z,h,two,draw,away,total,homeBias,under15,under05,
  eligible:issues.length===0,issues};
}
// Competition tier is a *selection-quality heuristic*, not a statement of proven profitability.
// A verified main league/cup is preferred for scarce research slots; unknown events remain C/PASS.
const SUSPECT_COMPETITION=/(?:friendl|exhibition|friendly|u[- ]?(?:16|17|18|19|20|21|22|23)\b|under[- ]?(?:16|17|18|19|20|21|22|23)\b|reserve|academy|youth|testimonial)/i;
const CUP_WORDS=/(?:cup|copa|pokal|coupe|trophy|champions league|europa league|conference league|libertadores|sudamericana|supercup|super cup|recopa|championship playoff)/i;
const riskLeague=f=>SUSPECT_COMPETITION.test(`${f.league?.name||''} ${f.teams?.home?.name||''} ${f.teams?.away?.name||''}`);
function competitionQuality(f){
 const name=String(f.league?.name||''),id=Number(f.league?.id);
 const cup=f.league?.type==='Cup'||CUP_WORDS.test(name);
 const recognized=!!(name.trim()&&Number.isInteger(id)&&id>0&&!riskLeague(f));
 return {recognized,cup,reason:recognized?'赛事身份已识别，最终准入看历史稳定性':'赛事资料缺失或属于友谊/青年/预备队等高变动赛事'};
}
// Tier comparison is meaningful only when BOTH domestic competitions can be identified.
// Never assume every different league/country has a quality mismatch.
function leagueTier(name,country){
 const n=String(name||'').toLowerCase().replace(/[-_.]/g,' ').trim(),c=String(country||'').toLowerCase();
 if(/(?:\bu\s?(?:17|19|20|21|23)\b|reserve|academy|amateur|regional|provincial)/.test(n))return null;
 if(/(?:league two|fourth division|4th division)/.test(n))return 4;
 if(/(?:league one|serie c|segunda b|third division|3 liga|3 bundesliga|3rd division|national league north|national league south)/.test(n))return 3;
 if(/(?:serie b|ligue 2|2 bundesliga|second division|segunda divisi[oó]n|championship|primera nacional)/.test(n))return 2;
 if(/(?:premier league|serie a|bundesliga|la liga|primera divisi[oó]n|ligue 1|eredivisie|primeira liga|j1 league|k league 1|major league soccer|mls|brasileir[aã]o|liga profesional|superliga|super league|pro league|first division|division 1|1 liga|liga 1)/.test(n))return 1;
 return null;
}
function cupMismatch(h,a,q){
 if(!q.cup)return {hard:false,watch:false,reason:'常规联赛历史可比'};
 if(!h.dominantLeagueId||!a.dominantLeagueId)return {hard:false,watch:true,reason:'杯赛缺少可辨认的两队主联赛'};
 const crossCountry=!!h.dominantLeagueCountry&&!!a.dominantLeagueCountry&&h.dominantLeagueCountry!==a.dominantLeagueCountry;
 const ht=leagueTier(h.dominantLeagueName,h.dominantLeagueCountry),at=leagueTier(a.dominantLeagueName,a.dominantLeagueCountry);
 const gap=ht!=null&&at!=null&& !crossCountry?Math.abs(ht-at):null;
 if(gap!=null&&gap>=2)return {hard:true,watch:true,reason:`跨级别杯赛：主队第${ht}级、客队第${at}级，正常比分样本不可直接外推`};
 if(gap===1)return {hard:false,watch:true,reason:'跨级别杯赛存在一级联赛差距，比赛动力与比分波动不可直接外推'};
 if(crossCountry&&(ht==null||at==null))return {hard:false,watch:true,reason:'跨国/跨联赛杯赛：主联赛层级无法比较'};
 return {hard:false,watch:false,reason:crossCountry?'跨国杯赛两队常规联赛层级已识别':'双方常规联赛层级接近'};
}

const finished=new Set(['FT','AET','PEN']);
const marketText=n=>String(n||'').toLowerCase().replace(/[–—_]/g,'-').replace(/\s+/g,' ').trim();
const isHalf=n=>/(?:\b1st\s*half\b|\bfirst\s*half\b|\bhalf[ -]*time\b|\b1h\b|\bht\b)/i.test(marketText(n));
function marketKind(name){
 const n=marketText(name), half=isHalf(n);
 if(/correct\s*score|exact\s*score/.test(n))return half?'score':null;
 if(/(?:over\s*\/\s*under|under\s*\/\s*over|total\s*goals?|goals?\s+o\/u)/.test(n)&&!/(?:team|corner|card|booking|yellow|asian|player)/.test(n))return half?'htOU':'ftOU';
 if(/(?:asian\s*handicap|^handicap$)/.test(n))return half?null:'ah';
 if(half&&/(?:winner|result|1\s*x\s*2)/.test(n)&&!/(?:\bft\b|full\s*time|half\s*time\s*\/)/.test(n))return 'ht1x2';
 if(!half&&/(?:^match\s*winner$|^1\s*x\s*2$|^full\s*time\s*(?:winner|result)$|^match\s*result$)/.test(n))return 'ft1x2';
 return null;
}
async function discoverMarkets(){
 const j=await api('odds/bets'), list=j.response||[], groups={score:[],ht1x2:[],ft1x2:[],htOU:[],ftOU:[],ah:[]};
 for(const bet of list){const k=marketKind(bet.name);if(k&&Number.isFinite(Number(bet.id)))groups[k].push({id:Number(bet.id),name:bet.name});}
 if(!groups.score.length)throw Error('未找到上半场正确比分盘口ID，已停止，防止全场比分赔率串盘。');
 app.markets=groups;
 log('上半场比分 '+groups.score.map(x=>`${x.id}:${x.name}`).join(' / '));
 for(const k of ['ht1x2','ft1x2','htOU','ftOU','ah'])log(`${k}：${groups[k].map(x=>x.id+':'+x.name).join(' / ')||'市场目录未找到'}`);
}
const marketHas=(type,bet)=>app.markets[type]?.some(x=>x.id===Number(bet.id))||false;
function parseScore(v){const m=String(v??'').trim().replace(/\s+/g,'').match(/^(\d{1,2})[:\-](\d{1,2})$/);return m?`${Number(m[1])}-${Number(m[2])}`:null;}
const is365=b=>/\bbet\s*365\b/i.test(b||'');
function scoreQuotesFrom(rows){
 const quotes=new Map();for(const row of rows){for(const b of row.bookmakers||[]){if(!is365(b.name))continue;for(const bet of b.bets||[]){if(!marketHas('score',bet))continue;for(const v of bet.values||[]){const score=parseScore(v.value),odd=Number(v.odd);if(!score||!Number.isFinite(odd)||odd<=1)continue;if(!quotes.has(score))quotes.set(score,[]);quotes.get(score).push({odd,bookmaker:'Bet365',bookmakerId:b.id,updatedAt:row.update||null});}}}}
 return quotes;
}
function priceQuotes(qs){
 const pool=(qs||[]).filter(q=>is365(q.bookmaker)&&Number.isFinite(q.odd)&&q.odd>1);
 if(!pool.length)return null;
 const selected=pool[pool.length-1];
 return {...selected,bet365:true,count:1,spread:0};
}
function numericHT(f){const h=f.score?.halftime?.home,a=f.score?.halftime?.away;if(!finished.has(f.fixture?.status?.short)||h==null||a==null||!Number.isFinite(Number(h))||!Number.isFinite(Number(a)))return null;return [Number(h),Number(a)];}
function stabilityMetrics(recent,venueGames){
 const source=recent.slice(0,10),totals=source.map(r=>r.gf+r.ga),differences=source.map(r=>r.gf-r.ga);
 const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
 const sd=a=>a.length?Math.sqrt(avg(a.map(v=>(v-avg(a))**2))):0;
 const first=source.slice(0,5),older=source.slice(5,10);
 const drift=older.length>=4?Math.abs(avg(first.map(v=>v.gf+v.ga))-avg(older.map(v=>v.gf+v.ga))):null;
 const defenseDrift=older.length>=4?Math.abs(avg(first.map(v=>v.ga))-avg(older.map(v=>v.ga))):null;
 const heavy=source.length?totals.filter(x=>x>=3).length/source.length:1;
 const extremes=source.length?differences.filter(x=>Math.abs(x)>=3).length/source.length:1;
 const venueAvg=avg(venueGames.map(r=>r.gf+r.ga));
 const venueDiff=venueGames.length>=4?Math.abs(venueAvg-avg(totals)):null;
 // Fixed thresholds are risk-management heuristics, NOT proven statistical cutoffs.
 const risk=(drift==null?20:Math.min(40,drift*25)) + (defenseDrift==null?8:Math.min(20,defenseDrift*20)) +
  Math.max(0,sd(totals)-1.15)*24+heavy*18+extremes*20+(venueDiff==null?8:Math.min(12,venueDiff*12));
 const score=Math.round(clamp(100-risk,0,100));
 const stable=source.length>=10&&venueGames.length>=4&&score>=66&&drift<=.70&&sd(totals)<=1.55&&heavy<=.35;
 const watch=source.length<8||venueGames.length<3||score<50|| (drift!=null&&drift>1.15)||sd(totals)>1.95||heavy>.55;
 return {score,stable,watch,n:source.length,venueN:venueGames.length,drift,defenseDrift,sdTotal:sd(totals),heavyRate:heavy,extremeMarginRate:extremes,venueDiff};
}
function history(teamId,fixtures,venue,kickoff,leagueId=null){
 // Use only genuine finished first-half results before the target fixture.
 const games=[...(fixtures||[])].sort((a,b)=>Date.parse(b.fixture?.date||0)-Date.parse(a.fixture?.date||0));
 const records=[];
 for(const f of games){
  const d=Date.parse(f.fixture?.date||'');
  if(!Number.isFinite(d)||(kickoff&&d>=Date.parse(kickoff)))continue;
  const score=numericHT(f);if(!score)continue;
  const isHome=Number(f.teams?.home?.id)===Number(teamId),isAway=Number(f.teams?.away?.id)===Number(teamId);
  if(!isHome&&!isAway)continue;
  if(riskLeague(f))continue;
  const leagueName=String(f.league?.name||''),leagueType=f.league?.type||'League';
  // Cup/friendly results can be extreme and are NOT training examples for regular-league stability.
  if(leagueType!=='League'||CUP_WORDS.test(leagueName))continue;
  records.push({gf:isHome?score[0]:score[1],ga:isHome?score[1]:score[0],home:isHome,date:d,leagueId:Number(f.league?.id)||null,leagueName,leagueCountry:String(f.league?.country||''),fixtureId:Number(f.fixture?.id)});
  if(records.length>=32)break;
 }
 const recent=records.slice(0,12),venueGames=records.filter(r=>r.home===(venue==='home')).slice(0,7);
 const sameLeague=leagueId!=null?recent.filter(r=>r.leagueId===Number(leagueId)):[];
 const byLeague=new Map();for(const row of recent){if(row.leagueId!=null)byLeague.set(row.leagueId,(byLeague.get(row.leagueId)||0)+1);}
 const dominantLeague=[...byLeague].sort((x,y)=>y[1]-x[1])[0]||[null,0];
 const domesticReference=recent.find(r=>r.leagueId===dominantLeague[0])||null;
 const stabilization=stabilityMetrics(recent,venueGames);
 const weighted=(rows,k)=>{const total=rows.reduce((t,r,i)=>t+Math.exp(-i/7),0);return total?rows.reduce((t,r,i)=>t+r[k]*Math.exp(-i/7),0)/total:0};
 const rate=(rows,fn)=>rows.length?rows.filter(fn).length/rows.length:0;
 const scored=weighted(recent,'gf'),conceded=weighted(recent,'ga');
 const venueN=venueGames.length,venueScored=weighted(venueGames,'gf'),venueConceded=weighted(venueGames,'ga');
 const venueWeight=Math.min(.66,venueN/7*.66);
 const attack=(1-venueWeight)*scored+venueWeight*venueScored;
 const defense=(1-venueWeight)*conceded+venueWeight*venueConceded;
 return {n:recent.length,venueN,sameLeagueN:sameLeague.length,dominantLeagueId:dominantLeague[0],dominantLeagueN:dominantLeague[1],dominantLeagueName:domesticReference?.leagueName||'',dominantLeagueCountry:domesticReference?.leagueCountry||'',referenceFixtureId:domesticReference?.fixtureId||null,referenceFixtureDate:domesticReference?.date||null,stability:stabilization,sameLeagueZeroRate:rate(sameLeague,r=>r.gf+r.ga===0),scored,conceded,venueScored,venueConceded,attack,defense,
  // Absolute sample counts are for display; rates are used with shrinkage.
  blank:recent.filter(v=>v.gf+v.ga===0).length,
  lead:recent.filter(v=>v.gf>v.ga).length,behind:recent.filter(v=>v.gf<v.ga).length,
  zeroFor:recent.filter(v=>v.gf===0).length,zeroAgainst:recent.filter(v=>v.ga===0).length,
  blankRate:rate(recent,r=>r.gf+r.ga===0),zeroForRate:rate(recent,r=>r.gf===0),
  zeroAgainstRate:rate(recent,r=>r.ga===0),twoPlusRate:rate(recent,r=>r.gf+r.ga>=2),
  venueZeroForRate:rate(venueGames,r=>r.gf===0),venueZeroAgainstRate:rate(venueGames,r=>r.ga===0),
  lastFiveFor:weighted(recent.slice(0,5),'gf'),lastFiveAgainst:weighted(recent.slice(0,5),'ga')};
}
function poisson(lambda,k){let fact=1;for(let n=2;n<=k;n++)fact*=n;return Math.exp(-lambda)*Math.pow(lambda,k)/fact;}
function footballOutcome(lh,la){let H=0,D=0,A=0,total=0;for(let i=0;i<=9;i++){for(let j=0;j<=9;j++){const p=poisson(lh,i)*poisson(la,j);total+=p;if(i>j)H+=p;else if(i===j)D+=p;else A+=p;}}return {home:H/total,draw:D/total,away:A/total};}
function overProbability(lambda,line){const n=Math.floor(line);let s=0;for(let i=0;i<=n;i++)s+=poisson(lambda,i);return 1-s;}
function outcomeKey(value){const s=String(value).trim().toLowerCase();if(['home','1','local'].includes(s))return 'home';if(['draw','x','tie'].includes(s))return 'draw';if(['away','2','visitor'].includes(s))return 'away';return null;}
function parseOU(value,name){let s=String(value||'').trim().toLowerCase();const m=s.match(/\b(over|under)\s*(\d+(?:\.\d+)?)\b/)||s.match(/\b(\d+(?:\.\d+)?)\s*(over|under)\b/);
 if(m){let side=Number.isFinite(Number(m[1]))?m[2]:m[1],line=Number.isFinite(Number(m[1]))?Number(m[1]):Number(m[2]);return {side,line};}
 const side=/^over$/i.test(s)?'over':/^under$/i.test(s)?'under':null;
 const inName=String(name||'').match(/(?:^|\s)(\d+(?:\.\d+)?)(?:\s|$)/);return side&&inName?{side,line:Number(inName[1])}:null;
}
function commonPrices(arr){const implied=arr.map(a=>1/a),sum=implied.reduce((s,p)=>s+p,0);return implied.map(p=>p/sum);}
// Use complete outcomes from the same bookmaker, never mix a Home price at Bet365 with Away elsewhere.
function extractOneMarket(rows,type){const outputs=[];for(const row of rows){for(const b of row.bookmakers||[]){for(const bet of b.bets||[]){if(!marketHas(type,bet))continue;
 const outcome={};for(const v of bet.values||[]){const odd=Number(v.odd);if(!Number.isFinite(odd)||odd<=1)continue;
 if(type==='ht1x2'||type==='ft1x2'){const k=outcomeKey(v.value);if(k)outcome[k]=odd;}
 else if(type==='htOU'||type==='ftOU'){const k=parseOU(v.value,bet.name);if(k&&[.5,1.5,2.5,3.5].includes(k.line))outcome[`${k.line}:${k.side}`]=odd;}
 else if(type==='ah'){const s=String(v.value),m=s.match(/(?:Home|Away|\b1\b|\b2\b)\s*([+-]?\d+(?:\.\d+)?)/i);if(m)outcome[s]=odd;}
 }
 if(type==='ht1x2'||type==='ft1x2'){if(['home','draw','away'].every(k=>outcome[k]>1)){const p=commonPrices([outcome.home,outcome.draw,outcome.away]);outputs.push({type,bookmaker:b.name||'未知',bookmakerId:b.id,odds:outcome,prob:{home:p[0],draw:p[1],away:p[2]}});}}
 else if(type==='htOU'||type==='ftOU'){for(const line of [.5,1.5,2.5,3.5]){const o=outcome[`${line}:over`],u=outcome[`${line}:under`];if(o>1&&u>1){const p=commonPrices([o,u]);outputs.push({type,line,bookmaker:b.name||'未知',bookmakerId:b.id,odds:{over:o,under:u},probOver:p[0]});}}}
 else if(type==='ah'&&Object.keys(outcome).length>0)outputs.push({type,bookmaker:b.name||'未知',odds:outcome});
 }}}
 return outputs;
}
function chooseBookmaker(options,preferredName){if(!options.length)return null;
 const preferred=options.filter(x=>is365(x.bookmaker));if(preferred.length)return preferred[0];
 if(preferredName){const same=options.find(x=>x.bookmaker===preferredName);if(same)return same;}
 return options[0];
}
function extractMarkets(rows,preferredName){const ft=chooseBookmaker(extractOneMarket(rows,'ft1x2'),preferredName),ht=chooseBookmaker(extractOneMarket(rows,'ht1x2'),preferredName);
 const allHT=extractOneMarket(rows,'htOU'),allFT=extractOneMarket(rows,'ftOU');
 const getOU=(list,line)=>chooseBookmaker(list.filter(x=>x.line===line),preferredName);
 return {ft,ht,htTotals:[.5,1.5,2.5].map(v=>getOU(allHT,v)).filter(Boolean),ftTotals:[1.5,2.5,3.5].map(v=>getOU(allFT,v)).filter(Boolean),ah:chooseBookmaker(extractOneMarket(rows,'ah'),preferredName)};
}
function historyPrior(home,away,market){
 // Venue-specific halftime attack/defense is stronger evidence than mixed home/away form.
 // Shrink small samples to conservative baselines instead of treating four matches as truth.
 const sample=Math.min(home.n,away.n),venueSample=Math.min(home.venueN,away.venueN);
 const reliability=clamp(.14+.48*Math.min(sample/12,1)+.28*Math.min(venueSample/6,1),.14,.90);
 const rawHome=.57*home.attack+.43*away.defense;
 const rawAway=.57*away.attack+.43*home.defense;
 let lh=.69*(1-reliability)+rawHome*reliability;
 let la=.53*(1-reliability)+rawAway*reliability;
 // HT scoreless tendencies corroborate or temper scoring rates; cap their influence.
 const hs=clamp(.5*(away.zeroAgainstRate-home.zeroForRate),-.20,.20);
 const as=clamp(.5*(home.zeroAgainstRate-away.zeroForRate),-.20,.20);
 lh*=1+hs*.16;la*=1+as*.16;
 lh=clamp(lh,.16,1.75);la=clamp(la,.14,1.65);
 const volatility=Math.max(Math.abs(home.lastFiveFor-home.scored),Math.abs(away.lastFiveFor-away.scored));
 return {lh,la,reliability,volatility};
}
function scoreProbability(score,rates){
 const [home,away]=score.split('-').map(Number);
 return poisson(rates.lh,home)*poisson(rates.la,away);
}
// One main and at most one backup. These are pre-match theoretical payouts;
// real live cash-out pricing is not supplied by either API.
function pairMetrics(primary,backup,prior){
 if(!primary?.quote?.bet365||!backup?.quote?.bet365)return null;
 const o1=primary.quote.odd,o2=backup.quote.odd;
 const breakeven=1/o1+1/o2,coveredProbability=primary.probability+backup.probability;
 const mainShare=(1/o1)/breakeven,backupShare=1-mainShare;
 const zeroRisk=Math.exp(-prior.lh-prior.la);
 return {mainScore:primary.score,backupScore:backup.score,coveredProbability,breakeven,
  edge:coveredProbability-breakeven,dutchingROI:coveredProbability/breakeven-1,
  mainShare,backupShare,zeroRisk,uncoveredZero:primary.score==='0-0'||backup.score==='0-0'?0:zeroRisk};
}
function chooseBackupPlan(primary,all,fit,h,a,mkt,minOdd){
 if(!primary)return null;
 // Preference: the other core score, then 2-0 and 1-1. The odds and EV
 // still have to justify a backup: never automatically call it a hedge.
 const valid=all.filter(p=>p.score!==primary.score&&targetScoreSet.includes(p.score)&&scorePriceOK(p,minOdd));
 const eligible=valid.filter(p=>scoreStructure(p.score,fit,h,a,mkt).eligible&&estimatedEV(p)>=.0);
 eligible.sort((a,b)=>Number(primaryScoreSet.includes(b.score))-Number(primaryScoreSet.includes(a.score))||
  (estimatedEV(b)??-99)-(estimatedEV(a)??-99)||b.probability-a.probability);
 return eligible[0]||null;
}
function modelFit(prior,market){
 let best={err:Infinity,lh:prior.lh,la:prior.la};
 const priorWeight=1.35+1.65*prior.reliability;
 for(let lh=.16;lh<=1.80;lh+=.055){for(let la=.14;la<=1.75;la+=.055){
  let err=priorWeight*(Math.log(lh/prior.lh)**2+Math.log(la/prior.la)**2);
  const o=market.ht?footballOutcome(lh,la):null;
  if(o)for(const k of ['home','draw','away'])err+=10*(o[k]-market.ht.prob[k])**2;
  for(const ou of market.htTotals){const weight=ou.line===1.5?12:ou.line===.5?10:5;err+=weight*(overProbability(lh+la,ou.line)-ou.probOver)**2;}
  if(err<best.err)best={err,lh,la};
 }}
 return best;
}
function marketsEvidence(prior,fit,mkt,h,a,scoreQuotes){
 const issues=[],context=[];let conflicts=0;
 context.push(`历史半场稳定性：主${h.stability?.score??'—'}/100、客${a.stability?.score??'—'}/100（历史估计未校准）`);
 const independent=footballOutcome(prior.lh,prior.la);
 if(mkt.ht){
  const p=mkt.ht.prob;
  context.push(`半场胜平负去水 主${pct(p.home)} / 平${pct(p.draw)} / 客${pct(p.away)} (${mkt.ht.bookmaker})`);
  if(Math.abs(independent.home-p.home)>.18||Math.abs(independent.away-p.away)>.18){issues.push('历史半场胜平负与市场不一致');conflicts++;}
  const fitted=footballOutcome(fit.lh,fit.la);
  if(Math.max(...['home','draw','away'].map(k=>Math.abs(fitted[k]-p[k])))>.12){issues.push('拟合后半场1X2仍与市场差异较大');conflicts++;}
 }else issues.push('缺少半场胜平负盘口');
 const ou15=mkt.htTotals.find(t=>t.line===1.5),ou05=mkt.htTotals.find(t=>t.line===.5);
 if(mkt.htTotals.length)context.push(`半场大小球去水 ${mkt.htTotals.map(t=>`${t.line}大${pct(t.probOver)} (${t.bookmaker})`).join(' / ')}`);
 else issues.push('缺少半场大小球盘口');
 for(const ou of mkt.htTotals){const gap=Math.abs(overProbability(prior.lh+prior.la,ou.line)-ou.probOver);
  if(gap>.17){issues.push(`历史进球分布与半场${ou.line}大小球差异${pct(gap)}`);conflicts++;}}
 const zeroRisk=scoreProbability('0-0',prior);
 context.push(`独立历史模型：0-0=${pct(zeroRisk)}、1-0=${pct(scoreProbability('1-0',prior))}、2-0=${pct(scoreProbability('2-0',prior))}、1-1=${pct(scoreProbability('1-1',prior))}`);
 if(ou05){const zeroMarket=1-ou05.probOver;
  context.push(`半场小0.5市场去水=${pct(zeroMarket)}，用于0-0概率核对`);
  if(Math.abs(zeroMarket-zeroRisk)>.17){issues.push('历史0-0概率与半场小0.5盘口冲突');conflicts++;}}
 if(ou05&&ou15&&ou05.probOver-ou15.probOver<-.025){issues.push('半场大小球概率次序错误');conflicts++;}
 // Check the RELATIVE odds of all four priority scores using independent
 // history; do not normalize against ineligible bookmaker/FT quotes.
 const quotes=targetScoreSet.map(score=>({score,quote:priceQuotes(scoreQuotes.get(score)),prob:scoreProbability(score,prior)}));
 const priced=quotes.filter(x=>x.quote);
 if(priced.length===4){
  const impliedSum=priced.reduce((v,x)=>v+1/x.quote.odd,0),modelSum=priced.reduce((v,x)=>v+x.prob,0);
  const gap=Math.max(...priced.map(x=>Math.abs(x.prob/modelSum-(1/x.quote.odd)/impliedSum)));
  context.push(`四个核心比分Bet365报价完整，相对概率最大差${pct(gap)}`);
  if(gap>.14){issues.push('四比分盘口相对分布与独立历史模型冲突');conflicts++;}
 }else issues.push(`四比分仅获得${priced.length}/4个真实Bet365半场报价`);
 if(h.venueN<3||a.venueN<3)issues.push('同场地主客样本不足');
 if(h.stability?.watch||a.stability?.watch)issues.push('半场历史波动或样本不足');
 if(prior.volatility>.48)issues.push('最近5场半场进球趋势偏移');
 return {issues,context,conflicts,zeroRisk,targetQuoteCount:priced.length,marketFit:{lh:fit.lh,la:fit.la},independentOutcome:independent};
}
function scorePlan(score,fit,quotes,mkt,home,away,evidence){
 const [h,a]=score.split('-').map(Number),p=poisson(fit.lh,h)*poisson(fit.la,a),quote=priceQuotes(quotes?.get(score));
 const style=(s,loc)=>`${loc}近${s.n}场半场进${money(s.scored)}失${money(s.conceded)}、${s.zeroFor}场零进球；其中本场地${s.venueN}场进${money(s.venueScored)}失${money(s.venueConceded)}`;
 const text=`${style(home,'主队')}; ${style(away,'客队')}。半场历史稳定性：主${home.stability?.score??'—'}/100、客${away.stability?.score??'—'}/100（尚未回测校准）。同场地加权攻防：主${money(home.attack)}/${money(home.defense)}、客${money(away.attack)}/${money(away.defense)}。半场预期进球主${money(fit.lh)} / 客${money(fit.la)}；${fit.lh>fit.la+.25?'主队攻势预期偏强':fit.la>fit.lh+.25?'客队攻势预期偏强':'双方上半场预期较接近'}。`;
 return {score,probability:p,quote,implied:quote?1/quote.odd:null,reason:text,risk:evidence.issues.slice(0,6).join('；')||'首发与临场状态尚未核对',lh:fit.lh,la:fit.la};
}
// Core ranking is an independently calculated result, not a score preference override.
function scoreStructure(score,fit,h,a,mkt){
 const profile=scoreRankingProfile(fit,mkt),issues=[...profile.issues];
 let eligible=profile.eligible;
 if(!targetScoreSet.includes(score)){issues.push('比分不属于本策略四比分优先级');eligible=false;}
 if(primaryScoreSet.includes(score)){
  if(profile.rank(score)>2){issues.push(`${score}未进入真实预测概率前两名`);eligible=false;}
 }else if(secondaryScoreSet.includes(score)){
  if(profile.rank(score)>4){issues.push(`${score}未进入真实预测概率前四名`);eligible=false;}
 }
 if(!mkt.ht||!mkt.htTotals.find(t=>t.line===1.5))issues.push('缺少半场1X2或小1.5交叉验证');
 return {eligible,issues,profile,total:profile.total};
}
function cupHistoryOK(h,a,quality){
 if(!quality.cup)return h.sameLeagueN>=4&&a.sameLeagueN>=4;
 // Cup opponents often play in distinct domestic leagues; don't demand same-cup sample.
 return h.dominantLeagueN>=6&&a.dominantLeagueN>=6;
}
// Conservative cup check. Actual XI is only accessible when provider publishes it.
function eleven(lineups,teamId){const row=(lineups||[]).find(x=>Number(x.team?.id)===Number(teamId));const xs=(row?.startXI||[]).map(x=>Number(x.player?.id)).filter(Number.isFinite);return xs.length>=10?new Set(xs):null;}
async function verifyCupLineups(f,h,a){
 const minutes=(Date.parse(f.fixture?.date||'')-Date.now())/60000;
 if(minutes>75||minutes<0)return {status:'unverified',reason:'杯赛尚未进入首发核验窗口，不能确认实际轮换'};
 if(!h.referenceFixtureId||!a.referenceFixtureId)return {status:'unverified',reason:'杯赛双方缺少可比较的上轮常规联赛首发'};
 // Last normal-league XI too old => not a suitable stable reference.
 if(Date.now()-Math.min(h.referenceFixtureDate||0,a.referenceFixtureDate||0)>35*86400000)return {status:'unverified',reason:'主联赛首发参考样本过旧'};
 try{
  const cur=(await api('fixtures/lineups',{fixture:f.fixture.id})).response||[];
  const hc=eleven(cur,f.teams.home.id),ac=eleven(cur,f.teams.away.id);
  if(!hc||!ac)return {status:'unverified',reason:'杯赛双方首发尚未公布或API未覆盖'};
  const [prevHome,prevAway]=await Promise.all([api('fixtures/lineups',{fixture:h.referenceFixtureId}),api('fixtures/lineups',{fixture:a.referenceFixtureId})]);
  const hp=eleven(prevHome.response,f.teams.home.id),ap=eleven(prevAway.response,f.teams.away.id);
  if(!hp||!ap)return {status:'unverified',reason:'缺少上轮联赛首发阵容，无法计算轮换人数'};
  const hStay=[...hc].filter(x=>hp.has(x)).length,aStay=[...ac].filter(x=>ap.has(x)).length;
  if(hStay<=5||aStay<=5)return {status:'rotation',reason:`杯赛首发大量轮换：主队沿用${hStay}/11、客队沿用${aStay}/11，直接排除`};
  if(hStay<8||aStay<8)return {status:'unverified',reason:`杯赛轮换偏大：主队沿用${hStay}/11、客队沿用${aStay}/11，降C观察`};
  return {status:'verified',reason:`首发对照上轮联赛：主队沿用${hStay}/11、客队沿用${aStay}/11`};
 }catch(err){log(`杯赛${f.fixture.id}首发核验失败：${err.message}`);return {status:'unverified',reason:'杯赛首发资料读取失败，谨慎降C'};}
}
function assessMatch(main,h,a,risky,mkt,evidence,minOdd,globalTop,fit,quality,lineup,backup=null,pair=null){
 const issues=[...evidence.issues],q=main.quote;
 const confidence=h.n>=10&&a.n>=10&&h.venueN>=5&&a.venueN>=5?'较充足':h.n>=7&&a.n>=7?'中等':'偏低';
 const ev=q?main.probability*q.odd-1:null,diff=q?main.probability-1/q.odd:null;
 const priceOK=scorePriceOK(main,minOdd),backupPriceOK=scorePriceOK(backup,minOdd);
 const profile=scoreRankingProfile(fit,mkt),structure=scoreStructure(main.score,fit,h,a,mkt);
 issues.push(...structure.issues);
 if(!priceOK)issues.push('主比分缺少有效Bet365半场正确比分报价或未达到对应门槛');
 if(!backupPriceOK)issues.push('无合格备用比分；只研究单一主方向，不能视作保单');
 if(!mkt.ht||!mkt.htTotals.some(x=>x.line===1.5))issues.push('缺少半场1X2/1.5大小球完整交叉验证');
 if(h.n<7||a.n<7||h.venueN<3||a.venueN<3)issues.push('双方近期半场或同场地主客历史样本不足');
 if(!cupHistoryOK(h,a,quality))issues.push('同联赛样本不足，或杯赛主联赛样本不足');
 if(!quality.recognized)issues.push(quality.reason);
 const mix=cupMismatch(h,a,quality),stable=h.stability?.stable&&a.stability?.stable;
 if(!stable||h.stability?.watch||a.stability?.watch)issues.push(`半场走势稳定性不足：主${h.stability?.score??'—'} / 客${a.stability?.score??'—'}`);
 if(mix.watch||mix.hard)issues.push(mix.reason);
 if(quality.cup&&lineup?.status!=='verified')issues.push(lineup?.reason||'杯赛首发未核实');
 if(risky)issues.push('友谊/青年/预备队风险');
 if(evidence.conflicts)issues.push('历史分布与市场有实质冲突');
 if(profile.rank(main.score)>2)issues.push('选中主比分并非真实预测概率前两名');
 if(evidence.targetQuoteCount<4)issues.push('四比分真实赔率不完整，不能列为A/B');
 if(pair){
  if(pair.edge<0)issues.push('两比分等额返还理论收益仍为负，不应强行配保本单');
  if(pair.breakeven>=1)issues.push('组合两项隐含概率相加≥100%，无法获得正收益');
 }
 if((q?.odd??0)>20)issues.push('赔率超过20，尾部分布估计不稳定');
 if(ev!==null&&ev<.04)issues.push(`主比分理论EV为${pct(ev)}，不满足4%研究阈值（尚未回测）`);
 const reliable=h.n>=8&&a.n>=8&&h.venueN>=4&&a.venueN>=4&&cupHistoryOK(h,a,quality)&&stable&&!mix.watch&&!mix.hard&&(!quality.cup||lineup?.status==='verified');
 const essential=priceOK&&mkt.ht&&mkt.htTotals.some(x=>x.line===1.5)&&reliable&&quality.recognized&&!risky&&
  !evidence.conflicts&&evidence.targetQuoteCount===4&&structure.eligible&&profile.eligible&&ev>=.04&&(q.odd<=20);
 let grade='PASS';
 if(essential){grade=(h.n>=10&&a.n>=10&&h.venueN>=5&&a.venueN>=5&&h.stability.score>=75&&a.stability.score>=75&&
  h.sameLeagueN>=6&&a.sameLeagueN>=6&&evidence.issues.length===0&&mkt.ht?.bookmaker&&is365(mkt.ht.bookmaker)&&
  mkt.htTotals.some(t=>t.line===1.5&&is365(t.bookmaker)))?'A':'B';}
 else if(priceOK&&!risky&&h.n>=5&&a.n>=5&&profile.strictTop&&profile.homeBias&&
  profile.coverage>=.57&&profile.rank(main.score)<=2)grade='C';
 if(mix.hard||lineup?.status==='rotation'||risky){grade='PASS';issues.push('高波动/跨级别/大量轮换，不参与');}
 if(['A','B'].includes(grade))issues.push('等待AI复核；失败则降C，不凭空提级');
 return {grade,reason:issues.filter(Boolean).join('；')||'主队低比分结构、历史与赔率交叉信号一致（未回测校准）',
  ev,diff,confidence,baseGrade:grade,modelVersion:'home-low-score-v1.1'};
}
// Selected matches are NOT allowed to be promoted merely because AI likes the team.
function applyAIVerdict(match,result){
 const v=match.verdict,base=v.baseGrade;
 if(!result){
  if(['A','B'].includes(base)){v.grade='C';v.reason+='；AI未完成有效复核，自动降级C级';}
  return;
 }
 const matchesPrimary=result.primary_score===match.main.score;
 const approved=result.decision==='可关注'&&matchesPrimary&&result.confidence!=='低';
 // Only retain an A/B if both the hard rules and AI agree. C/PASS cannot be upgraded by AI.
 if(['A','B'].includes(base)){
  if(approved){v.grade=base;v.reason+='；AI批量复核确认：'+String(result.reason||'风险证据相符').slice(0,110);}
  else {v.grade=result.decision==='PASS'?'PASS':'C';v.reason+='；AI批量复核不通过：'+String(result.reason||'主要比分或风险不一致').slice(0,110);}
 } else if(base==='C'){
  v.grade=result.decision==='PASS'?'PASS':'C';
  v.reason+='；AI批量审查：'+String(result.reason||'仍存在本地证据缺口').slice(0,110)+'；不得越过硬筛选条件升级';
 }
 v.aiScreen={decision:result.decision,reason:result.reason||'',confidence:result.confidence,primary_score:result.primary_score};
}
// Only the TWO highest-probability core scores can become main selections.
function chooseMainPlan(all,fit,home,away,mkt,minOdd){
 const profile=scoreRankingProfile(fit,mkt);
 if(!profile.strictTop||!profile.homeBias)return null;
 const eligible=all.filter(p=>primaryScoreSet.includes(p.score)&&scorePriceOK(p,minOdd)&&
  scoreStructure(p.score,fit,home,away,mkt).eligible);
 // Prioritize price-justified core scores; within equal value class retain probability ordering.
 eligible.sort((a,b)=>Number((estimatedEV(b)??-1)>=.04)-Number((estimatedEV(a)??-1)>=.04)||
  b.probability-a.probability||(estimatedEV(b)??-99)-(estimatedEV(a)??-99));
 return eligible[0]||null;
}
function rankingCompare(a,b){
 const order={A:0,B:1,C:2,PASS:3};
 return order[a.verdict.grade]-order[b.verdict.grade]||b.main.probability-a.main.probability||new Date(a.f.fixture.date)-new Date(b.f.fixture.date);
}
function compactAIScreenInput(x){
 return {fixtureId:Number(x.f.fixture.id),league:`${x.f.league?.country||''} ${x.f.league?.name||''}`,
  home:x.f.teams.home.name,away:x.f.teams.away.name,kickoff:x.f.fixture.date,
  localGrade:x.verdict.baseGrade,localPrimary:x.main.score,localBackup:x.backup?.score||null,localProbability:Number((x.main.probability*100).toFixed(1)),pair:x.pair?{coverage:Number((x.pair.coveredProbability*100).toFixed(1)),breakeven:Number((x.pair.breakeven*100).toFixed(1)),zeroRisk:Number((x.pair.zeroRisk*100).toFixed(1)),theoreticalROI:Number((x.pair.dutchingROI*100).toFixed(1))}:null,
  targetQuotes:referenceSet.map(score=>({score,odds:x.refs?.[score]?.quote?.odd??null,bookmaker:x.refs?.[score]?.quote?.bookmaker||null,probability:Number((x.refs?.[score]?.probability*100||0).toFixed(1))})),
  competition:{type:x.f.league?.type||null,recognized:x.quality.recognized,cup:x.quality.cup,cupMismatch:cupMismatch(x.h,x.a,x.quality),lineup:x.lineup},
  modelExpectedGoalsHT:{home:Number(x.main.lh.toFixed(2)),away:Number(x.main.la.toFixed(2))},
  homeHT:{n:x.h.n,venueN:x.h.venueN,sameLeagueN:x.h.sameLeagueN,dominantLeagueN:x.h.dominantLeagueN,dominantLeagueName:x.h.dominantLeagueName,stability:x.h.stability,blankRate:x.h.blankRate,twoPlusRate:x.h.twoPlusRate,scored:Number(x.h.scored.toFixed(2)),conceded:Number(x.h.conceded.toFixed(2))},
  awayHT:{n:x.a.n,venueN:x.a.venueN,sameLeagueN:x.a.sameLeagueN,dominantLeagueN:x.a.dominantLeagueN,dominantLeagueName:x.a.dominantLeagueName,stability:x.a.stability,blankRate:x.a.blankRate,twoPlusRate:x.a.twoPlusRate,scored:Number(x.a.scored.toFixed(2)),conceded:Number(x.a.conceded.toFixed(2))},
  ranks:{home:(recentStandingItem(x.f,x.f.teams.home.id)?.rank??null),away:(recentStandingItem(x.f,x.f.teams.away.id)?.rank??null)},
  ht1x2:x.markets.ht?.prob||null,marketFittedHT:{home:x.evidence.marketFit.lh,away:x.evidence.marketFit.la},
  htOU:x.markets.htTotals.map(t=>({line:t.line,probOver:Number(t.probOver.toFixed(3))})),
  contradictions:x.evidence.issues};
}
async function reviewBatchWithAI(matches){
 // Local mandatory filters determine which fixtures are even worth spending AI tokens on.
 // C watchlist is included so the batch API genuinely evaluates the full price-qualified pool.
 const cfg=getOpenAIConfig(false);
 const candidates=matches.filter(x=>
  x.quality.recognized&&scorePriceOK(x.main,Number(el('minOdd').value))&&
  !x.risk&&x.h.n>=5&&x.a.n>=5&&['A','B','C'].includes(x.verdict.baseGrade));
 const initial=matches.filter(x=>['A','B'].includes(x.verdict.baseGrade));
 if(!cfg.key){for(const x of initial)applyAIVerdict(x,null);if(initial.length)log(`初筛有${initial.length}场A/B，但未配置OpenAI Key；全部降级C观察。`);return;}
 if(!candidates.length){log('0-0≥3、1-0≥4以及主场低比分稳定性审核后无AI复核对象；PASS/C不凑数。');return;}
 // League-table lookup uses the same standings cache and endpoint as the existing single-match popup.
 // Unknown ranks stay null, never fabricated. Network failure cannot upgrade a match.
 const leagueSamples=new Map();
 for(const x of candidates){const l=x.f.league;if(l?.id!=null&&l?.season!=null)leagueSamples.set(`${l.id}:${l.season}`,x.f);}
 for(const f of leagueSamples.values()){
  if(app.cancel)throw Error('用户停止扫描');
  await loadRecentStandings(f);
 }
 const system='你是上半场主队低比分概率与赔率风险审计员。0-0和1-0为最高概率组，2-0和1-1为次选组，0-1及其他比分做风险参考。主方向只允许0-0或1-0；0-0真实Bet365半场赔率必须≥3，其他推荐比分赔率≥4。依据两队最近半场结果、主客同场地、稳定性、真实半场1X2、大小球0.5/1.5/2.5和正确比分赔率审计，绝对不能将理想排序当成真实概率或编造缺失数据。若客队进球风险大、四比分集中度不足、盘口冲突、AI无证据则PASS。AI不得升级C/PASS，不能换主比分，也不能将保险看作保证回本。';
 const results=new Map(),schema={type:'object',additionalProperties:false,properties:{matches:{type:'array',items:{type:'object',additionalProperties:false,properties:{fixtureId:{type:'integer'},decision:{type:'string',enum:['PASS','可关注']},primary_score:{type:'string',enum:[...primaryScoreSet,'PASS']},confidence:{type:'string',enum:['低','中','高']},reason:{type:'string'}},required:['fixtureId','decision','primary_score','confidence','reason']}}},required:['matches']};
 for(let start=0;start<candidates.length;start+=6){
  if(app.cancel)throw Error('用户停止扫描');
  const chunk=candidates.slice(start,start+6);
  const user=`审核以下${chunk.length}场并返回JSON。每场解释历史半场数据是否真实支持0-0/1-0前两名、2-0/1-1次选，主队优势是否可靠；对照半场1X2/大小球及Bet365真实比分赔率。0-0≥3，1-0/2-0/1-1≥4；不能把实际0-1风险降为0。decision=PASS或可关注，primary_score只能维持localPrimary或PASS，不能改变主比分。判断盘口冲突、阵容风险和价值不足情况。C级只能观察，AI不能提升。每个fixtureId各返回一次。\n数据：${JSON.stringify(chunk.map(compactAIScreenInput))}`;
  try{
   const resp=await requestAICompletion({model:cfg.model,messages:[{role:'system',content:system},{role:'user',content:user}],temperature:0.1,response_format:{type:'json_schema',json_schema:{name:'halftime_bulk_audit',strict:true,schema}}},cfg.key);
   const parsed=JSON.parse(cleanJsonBlock(extractJsonText(resp.choices?.[0]?.message?.content||'')));
   if(!Array.isArray(parsed.matches))throw Error('AI未返回matches数组');
   for(const r of parsed.matches){if(!r||!Number.isSafeInteger(Number(r.fixtureId))||!['PASS','可关注'].includes(r.decision)||![...primaryScoreSet,'PASS'].includes(r.primary_score)||!['低','中','高'].includes(r.confidence))continue;
    const id=Number(r.fixtureId);if(chunk.some(x=>Number(x.f.fixture.id)===id)&&!results.has(id))results.set(id,r);
   }
  }catch(e){log(`AI复核批次${Math.floor(start/6)+1}失败：${e.message}`);}
  out(`阶段6/6：ChatGPT API已审核${Math.min(start+6,candidates.length)}/${candidates.length}场；失败的A/B候选只降级观察。`);
 }
 for(const x of candidates)applyAIVerdict(x,results.get(Number(x.f.fixture.id))||null);
 // Any A/B not returned by AI must also be downgraded (e.g. no primary quote).
 for(const x of initial)if(!x.verdict.aiScreen&&['A','B'].includes(x.verdict.grade))applyAIVerdict(x,null);
 log(`批量AI已收到${results.size}/${candidates.length}场有效复核结果。`);
}
async function scan(){
 app.cancel=false;app.calls=0;app.studied=0;app.markets={};app.ranked=[];app.selected.clear();app.partial=false;app.riskDropped=0;app.histories.clear();app.expandedHistory.clear();app.standingCache.clear();renderResults();renderGroups();renderProgress(0);setRunning(true);
 app.key=getKey();const date=el('day').value,minOdd=Number(el('minOdd').value),depth=Number(el('deepCount').value);
 if(!date||!Number.isFinite(minOdd)||minOdd<MIN_ODD||minOdd>30)throw Error('请确认日期，Bet365半场正确比分最低赔率必须≥4.00，输入上限为30。');
 log(`开始扫描 ${date}；0-0≥3.00，1-0/2-0/1-1≥${money(minOdd)}；概率前两名须是0-0/1-0，前四名包含2-0/1-1；深度${depth}场`);
 out('阶段1/5：读取真实赛程、识别每类盘口市场ID…');
 const [fixtures]=await Promise.all([api('fixtures',{date,timezone:TZ}),discoverMarkets()]);
 app.fixtures=(fixtures.response||[]).filter(f=>f.fixture?.id&&f.teams?.home?.id&&f.teams?.away?.id&&f.fixture?.status?.short==='NS');
 el('fixturesNum').textContent=String(app.fixtures.length);renderProgress(.08);
 const byFixture=new Map(app.fixtures.map(f=>[Number(f.fixture.id),f]));
 const quotesByFixture=new Map(),priceMarkets=app.markets.score.slice(0,2);if(app.markets.score.length>2){app.partial=true;log('正确比分市场ID超过2个，本版只扫描前2个以避免过大额度。');}
 out('阶段2/5：获取所有比赛的上半场正确比分实际报价，不按赔率排序…');
 for(const bet of priceMarkets){
  let page=1,allPages=1;const maxPages=75;
  do{if(app.cancel)throw Error('用户停止扫描');const j=await api('odds',{date,timezone:TZ,bet:bet.id,page});
   for(const row of j.response||[]){const fid=Number(row.fixture?.id);if(!byFixture.has(fid))continue;if(!quotesByFixture.has(fid))quotesByFixture.set(fid,[]);quotesByFixture.get(fid).push(row);}
   allPages=Math.max(1,Number(j.paging?.total)||1);out(`阶段2/5：半场比分赔率 bet=${bet.id}，页码${page}/${allPages}，累计${quotesByFixture.size}场…`);
   renderProgress(.08+.22*((priceMarkets.indexOf(bet)+(page/Math.max(1,Math.min(allPages,maxPages))))/priceMarkets.length));
   page++;if(page<=allPages&&page<=maxPages)await sleep(55);
  }while(page<=allPages&&page<=maxPages);
  if(allPages>maxPages){app.partial=true;log(`盘口${bet.id}超过${maxPages}页，扫描不完整`)}
 }
 let priced=[];for(const [fid,rows] of quotesByFixture){const f=byFixture.get(fid),scoreQuotes=scoreQuotesFrom(rows);if(!scoreQuotes.size)continue;
 // Only consider fixtures with verified target correct-score markets; never invent available prices.
 priced.push({f,scoreQuotes,initialRows:rows,risk:riskLeague(f),coverage:[...scoreQuotes.values()].reduce((best,qs)=>Math.max(best,new Set(qs.map(q=>q.bookmaker)).size),0)});
 }
 el('oddsNum').textContent=String(priced.length);
 let eligible=priced.filter(x=>(competitionQuality(x.f).recognized||(!el('skipRisk').checked&&x.risk))&&
  (!x.risk||!el('skipRisk').checked)&&primaryScoreSet.some(score=>qualifiesPrice(priceQuotes(x.scoreQuotes.get(score)),minOdd,score)));
 app.riskDropped=priced.filter(x=>x.risk&&el('skipRisk').checked).length;
 // Only the 0-0 / 1-0 main-score price gates drive research priority;
 // high-priced 0-1 alone is not a main-score candidate.
 const priority=item=>{
  const q=competitionQuality(item.f);
  const zeroOK=qualifiesPrice(priceQuotes(item.scoreQuotes.get('0-0')),minOdd,'0-0');
  const homeOK=qualifiesPrice(priceQuotes(item.scoreQuotes.get('1-0')),minOdd,'1-0');
  const backups=secondaryScoreSet.filter(score=>qualifiesPrice(priceQuotes(item.scoreQuotes.get(score)),minOdd,score)).length;
  return (q.recognized?15:0)+(zeroOK?110:0)+(homeOK?115:0)+(zeroOK&&homeOK?70:0)+backups*25;
 };
 eligible.sort((a,b)=>priority(b)-priority(a)||Number(a.risk)-Number(b.risk)||new Date(a.f.fixture.date)-new Date(b.f.fixture.date));
 if(eligible.length>depth){app.partial=true;log(`符合赔率门槛的赛事有${eligible.length}场，只研究前${depth}场，未研究比赛不是PASS判定。`)}
 eligible=eligible.slice(0,depth);
 if(!eligible.length){out('未找到真实Bet365半场0-0≥3或1-0≥4的比赛；本次不生成候选。');renderProgress(1);try{await refreshArchive(8)}catch(e){log('复盘更新失败：'+e.message)}return}
 out(`阶段3/5：逐场读取${eligible.length}场的半场交叉盘口，包含上半场大小球、半场胜平负…`);
 let cur=0;const fullRows=new Map();const enrichWorker=async()=>{while(cur<eligible.length){if(app.cancel)throw Error('用户停止扫描');const item=eligible[cur++],fid=Number(item.f.fixture.id);
  try{
   const rows=[];let page=1,total=1;const maxPages=12;
   do{
    const j=await api('odds',{fixture:fid,page});rows.push(...(j.response||[]));total=Math.max(1,Number(j.paging?.total)||1);
    const markets=extractMarkets(rows,null),scores=scoreQuotesFrom(rows);
    // Stop early only once HT 1X2 + 1.5 O/U and the original eight-score reference prices are present.
    // Multi-bookmaker fixture odds are paginated; don't mistake a partial page for complete evidence.
    if(markets.ht&&markets.htTotals.some(x=>x.line===1.5)&&referenceSet.every(s=>scores.has(s)))break;
    page++;
   }while(page<=Math.min(total,maxPages));
   if(page>=maxPages&&total>maxPages){app.partial=true;log(`比赛${fid}完整盘口超过${maxPages}页，部分盘口可能仍缺失。`)}
   fullRows.set(fid,rows);
  }catch(e){fullRows.set(fid,[]);log(`比赛${fid}完整盘口缺失：${e.message}`)}
  out(`阶段3/5：完整盘口已读取${fullRows.size}/${eligible.length}场`);renderProgress(.3+.24*fullRows.size/eligible.length);
 }};
 await Promise.all(Array.from({length:Math.min(3,eligible.length)},()=>enrichWorker()));
 out(`阶段4/5：读取${eligible.length}场双方最近12场+同场地主客7场的半场表现（单队读取最多40场）…`);
 const teams=[...new Set(eligible.flatMap(x=>[x.f.teams.home.id,x.f.teams.away.id]))];const cache=new Map();cur=0;
 const historyWorker=async()=>{while(cur<teams.length){if(app.cancel)throw Error('用户停止扫描');const id=teams[cur++];try{const j=await api('fixtures',{team:id,last:40});cache.set(id,j.response||[]);}catch(e){cache.set(id,[]);log(`球队${id}近期比赛请求失败：${e.message}`)}
  app.studied=cache.size;out(`阶段4/5：已读取${cache.size}/${teams.length}支球队近期记录`);renderProgress(.54+.34*cache.size/teams.length);
 }};
 await Promise.all(Array.from({length:Math.min(4,teams.length)},()=>historyWorker()));
 for(const [tid,records] of cache)app.histories.set(Number(tid),records);
 out('阶段5/6：主队0-0/1-0领先，2-0/1-1次选的概率结构与跨盘口审核…');
 const ranked=[];for(const item of eligible){
  const f=item.f,fid=Number(f.fixture.id),h=history(f.teams.home.id,cache.get(f.teams.home.id)||[],'home',f.fixture.date,f.league?.id),a=history(f.teams.away.id,cache.get(f.teams.away.id)||[],'away',f.fixture.date,f.league?.id);
  if(h.n<4||a.n<4){log(`跳过 ${fid}: 半场历史样本${h.n}/${a.n}不足4场`);continue;}
  // Enrich from the full fixture odds; if unavailable retain the original verified score market.
  const full=fullRows.get(fid)||[],additional=scoreQuotesFrom(full),scoreQuotes=new Map(item.scoreQuotes);
  for(const [score,qs] of additional){if(!scoreQuotes.has(score))scoreQuotes.set(score,qs);}
  const refPrice='Bet365';
  const mkt=extractMarkets(full,refPrice),prior=historyPrior(h,a,mkt),fit=modelFit(prior,mkt),evidence=marketsEvidence(prior,fit,mkt,h,a,scoreQuotes);
  // Independent probability uses HISTORY ONLY. Market fit is a cross-check, never used for EV.
  const all=scoreSet.map(score=>scorePlan(score,prior,scoreQuotes,mkt,h,a,evidence)).sort((x,y)=>y.probability-x.probability);
  const main=chooseMainPlan(all,prior,h,a,mkt,minOdd);
  // Only 0-0/1-0 can be main selections; all probabilities come from history, not preferences.
  if(!main){log(`跳过 ${fid}: 半场0-0/1-0概率结构或真实Bet365最低赔率不符`);continue;}
  const quality=competitionQuality(f);
  const mismatch=cupMismatch(h,a,quality);
  const preliminaryOK=h.stability.stable&&a.stability.stable&&!mismatch.hard&&!mismatch.watch&&!evidence.conflicts;
  const lineup=quality.cup&&preliminaryOK?await verifyCupLineups(f,h,a):{status:'unverified',reason:'杯赛未满足稳定性前置审核，不增加首发API调用'};
  const backup=chooseBackupPlan(main,all,prior,h,a,mkt,minOdd),pair=pairMetrics(main,backup,prior);
  const globalTop=all[0]||main;
  const verdict=assessMatch(main,h,a,item.risk,mkt,evidence,minOdd,globalTop,prior,quality,lineup,backup,pair);
  const refs=Object.fromEntries(referenceSet.map(score=>[score,all.find(p=>p.score===score)]));
  const targets=Object.fromEntries(targetScoreSet.map(score=>[score,all.find(p=>p.score===score)]));
  ranked.push({f,h,a,main,backup,pair,prior,fit,refs,targets,markets:mkt,evidence,quality,lineup,score:main.probability,verdict,risk:item.risk,alternatives:all.filter(p=>targetScoreSet.includes(p.score)&&p.score!==main.score).slice(0,3).map(p=>({score:p.score,probability:p.probability}))});
 }
 // Only a valid AI review can preserve A/B; if no Key or AI fails, candidates become C.
 app.ranked=ranked;
 out('阶段6/6：AI复核0-0/1-0、2-0/1-1概率顺序和风险，失败不通过…');
 await reviewBatchWithAI(ranked);
 ranked.sort(rankingCompare);
 saveScanSnapshots(ranked);
 el('studiedNum').textContent=String(ranked.length);renderResults();renderGroups();renderProgress(1);
 const valid=ranked.filter(x=>['A','B'].includes(x.verdict.grade)),c=ranked.filter(x=>x.verdict.grade==='C').length,pass=ranked.length-valid.length-c,target=Math.max(1,Number(el('goalCount').value)||10);
 out(`扫描完成：A/B可选择${valid.length}场、C仅观察${c}场、PASS ${pass}场；${valid.length<target?'未达到目标'+target+'场，不强行凑数。':''}累计API调用${app.calls}次。${app.partial?'⚠ 数据可能受研究上限或赔率分页限制。':''}`);
 log(`完成：A/B ${valid.length}, C ${c}, PASS ${pass}, API ${app.calls}次`);
 try{await refreshArchive(8)}catch(err){log('自动复盘未能完成：'+err.message)}
}

function renderResults(){
 const valid=app.ranked.filter(x=>['A','B'].includes(x.verdict.grade));
 el('candidatesNum').textContent=String(valid.length);const box=el('results');
 if(!app.ranked.length){box.innerHTML='<div class="empty">尚无通过数据稳定性审核的 Bet365 半场正确比分候选；关键盘口缺失不会伪造候选。</div>';el('pickTop').disabled=true;el('clear').disabled=true;return;}
 el('pickTop').disabled=!valid.length;el('clear').disabled=!app.selected.size;
 box.innerHTML=app.ranked.map((x,i)=>{
  const f=x.f,home=esc(f.teams.home.name),away=esc(f.teams.away.name),p=x.main,v=x.verdict,id=`${f.fixture.id}:${p.score}`;
  const pass=v.grade==='PASS',watch=v.grade==='C',selectable=true;
  const heading=pass?'PASS / 不参与':watch?'C级仅观察':`${v.grade}级候选`;
  const price=p.quote?.bet365?money(p.quote.odd):'—';
  const bk=p.quote?.bet365?'Bet365':'无 Bet365 半场正确比分报价';
  const refs=referenceSet.map(score=>{const entry=x.refs[score];const q=entry?.quote,inRange=targetScoreSet.includes(score)&&qualifiesPrice(q,Number(el('minOdd').value),score);
    return `<div class="refscore ${inRange?'inrange':''}"><strong>${score}</strong><span class="refprice mono">${q?.bet365?money(q.odd):'—'}</span><small>Bet365</small><small>模型 ${entry?pct(entry.probability):'—'}</small></div>`;
  }).join('');
  const context=x.evidence.context.map(v=>`<span>${esc(v)}</span>`).join('');
  const diff=v.diff==null?'不可计算':`${v.diff>=0?'+':''}${(v.diff*100).toFixed(1)}个百分点`;
  const ev=v.ev==null?'不可计算':`${v.ev>=0?'+':''}${(v.ev*100).toFixed(1)}%`;
  const modelAlt=x.alternatives.map(a=>`${a.score} ${pct(a.probability)}`).join(' · ');
  const pair=x.pair,backup=x.backup,profile=scoreRankingProfile(x.prior,x.markets);
  const pairNote=pair?`<div class="alt">0-0/1-0合计<b>${pct(profile.first)}</b>，四比分合计<b>${pct(profile.coverage)}</b>；实际概率顺序 <b>${esc(profile.all.slice(0,5).map(x=>x.score).join(' ＞ '))}</b>。主<b>${esc(p.score)}</b>（${money(p.quote.odd)}）＋次选<b>${esc(backup.score)}</b>（${money(backup.quote.odd)}），两项合计概率 ${pct(pair.coveredProbability)}，等额返还所需概率 ${pct(pair.breakeven)}，理论差${pair.edge>=0?'+':''}${pct(pair.edge)}；理论等额返还投注比例 主${(pair.mainShare*100).toFixed(0)}% / 备${(pair.backupShare*100).toFixed(0)}%。这些不是滚球早结报价，不等于真实保本。</div>`:
   `<div class="alt">0-0/1-0合计<b>${pct(profile.first)}</b>，四比分合计<b>${pct(profile.coverage)}</b>；实际概率排序 <b>${esc(profile.all.slice(0,5).map(x=>x.score).join(' ＞ '))}</b>。当前没有同时满足赔率、概率与理论价值的备用比分；仅观察单一主方向，不虚构保单。</div>`;
  return `${i&&['C','PASS'].includes(v.grade)&&app.ranked[i-1].verdict.grade!==v.grade?`<div class="passSeparator">${v.grade==='C'?'C级 · 仅观察':'PASS · 不参与'}（组内主比分按概率排序）</div>`:''}
  <article class="match ${pass?'isPass':watch?'isWatch':''}">
   <div class="rank">#${i+1}</div>
   <div class="leagueCell"><div class="mono">${hm(f.fixture.date)}</div><div class="small">${esc(ymd(f.fixture.date).slice(5))}</div></div>
   <div class="identity"><div class="league">${esc(f.league?.country||'')} · ${esc(f.league?.name||'')}</div><div class="teams">${home} <span class="muted">vs</span> ${away}</div><div class="small">主队在前 / 客队在后 <span class="pill ${pass?'pass':watch?'cgrade':''}">${heading}</span></div></div>
   <div class="scoreCell"><div class="scoreOddBox"><div class="score">${esc(p.score)}</div><div class="oddNum">${price}</div><div class="book">Bet365 · HT</div></div><div class="book">独立历史概率＋市场复核</div><label class="pick"><input data-select="${esc(id)}" type="checkbox" ${app.selected.has(id)?'checked':''}> 图片勾选</label>${watch||pass?'<div class="book">仅用于研究导出，保持原评级</div>':''}</div>
   <div class="priceCell"><div class="odds mono">${v.ev===null?'—':`${v.ev>=0?'+':''}${(v.ev*100).toFixed(1)}%`}</div><div class="book">独立模型理论EV · 未校准</div><div class="book">${bk}</div></div>
   <div class="probCell"><div class="p mono">${pct(p.probability)}</div><div class="small">模型概率 · 未校准</div></div>
   <div class="reasonCell"><div class="recentBtns"><button type="button" class="recentBtn singlePNG" data-onepng="${esc(f.fixture.id)}">🖼️ 单场生成图片</button><button type="button" class="recentBtn ai" data-ai="open" data-fixture="${esc(f.fixture.id)}">🧠 AI分析</button><button type="button" class="recentBtn" data-recent="half" data-fixture="${esc(f.fixture.id)}">📊 最近7场半场战绩＋积分排名</button><button type="button" class="recentBtn full" data-recent="full" data-fixture="${esc(f.fixture.id)}">📈 最近7场全场战绩＋积分排名</button></div><div class="reason">${esc(p.reason)}</div><div class="marketEvidence">${context||'<span>未获得完整的交叉盘口</span>'}</div><div class="refTitle">原版八比分 Bet365 半场正确比分赔率 <span class="small">（全部保留；绿色表示0-0≥3或其他候选≥4）</span></div>
   <div class="refGrid">${refs}</div>${pairNote}<div class="small">次选与风险比分：${esc(modelAlt)}（按独立历史概率排列）</div>
   <div class="risk">风险/缺失：${esc(p.risk)}；${esc(v.reason)}</div>
   <div class="marketDelta ${v.ev===null||v.ev<0?'negative':''}">主比分报价隐含概率 ${p.implied===null?'无':pct(p.implied)} ｜ 历史独立概率与报价差 ${diff} ｜ 理论EV ${ev}</div>
   <div class="small">赔率快照可能过时；独立模型未经概率校准。该评级仅用于赛前研究一致性筛选，不代表真实命中率或已验证的盈利优势；临场首发和比赛动态未核对。</div>
   </div>
  </article>`;
 }).join('');
 box.querySelectorAll('input[data-select]').forEach(input=>input.addEventListener('change',()=>{
  if(input.checked)app.selected.add(input.dataset.select);else app.selected.delete(input.dataset.select);
  renderGroups();el('clear').disabled=!app.selected.size;
 }));
}


// v3.3: 按需打开两队最近7场数据。沿用扫描阶段的真实 fixtures 缓存，不另行修改主模型。
const recentOverlay=el('recentOverlay');
let recentTrigger=null;
const recentDate=date=>ymd(date).slice(5);
function recentScoreValues(f,mode){
 if(!finished.has(f.fixture?.status?.short))return null;
 let s=mode==='half'?f.score?.halftime:f.score?.fulltime;
 if(mode==='full'&&(s?.home==null||s?.away==null))s=f.goals;
 if(s?.home==null||s?.away==null)return null;
 const h=Number(s.home),a=Number(s.away);
 return Number.isInteger(h)&&Number.isInteger(a)&&h>=0&&a>=0?[h,a]:null;
}
function recentSeven(teamId,fixtures,mode,kickoff){
 return (fixtures||[]).filter(f=>{
  const d=Date.parse(f.fixture?.date||'');
  return Number.isFinite(d)&&(!kickoff||d<Date.parse(kickoff))&&
   (Number(f.teams?.home?.id)===Number(teamId)||Number(f.teams?.away?.id)===Number(teamId))&&recentScoreValues(f,mode);
 }).sort((a,b)=>Date.parse(b.fixture.date)-Date.parse(a.fixture.date)).slice(0,7).map(f=>{
  const isHome=Number(f.teams.home.id)===Number(teamId);
  const [h,a]=recentScoreValues(f,mode),gf=isHome?h:a,ga=isHome?a:h;
  return {date:f.fixture.date,home:isHome,opponent:isHome?f.teams.away.name:f.teams.home.name,gf,ga,result:gf>ga?'win':gf<ga?'loss':'draw'};
 });
}
function recentStandingItem(f,teamId){
 const key=`${f.league?.id??''}:${f.league?.season??''}`;
 const group=app.standingCache.get(key);
 return group?.rows.find(v=>Number(v.team?.id)===Number(teamId))||null;
}
async function loadRecentStandings(f){
 const l=f.league;if(l?.id==null||l?.season==null)return;
 const key=`${l.id}:${l.season}`;
 if(app.standingCache.has(key))return;
 try{
  const j=await api('standings',{league:l.id,season:l.season});
  const rows=(j.response||[]).flatMap(v=>(v.league?.standings||[]).flat()).filter(x=>x&&x.team?.id);
  app.standingCache.set(key,{rows});
 }catch(e){app.standingCache.set(key,{rows:[],error:e.message});log(`赛事积分榜不可用：${e.message}`);}
}
async function loadRecentHistory(teamId,mode,kickoff){
 let rows=app.histories.get(teamId)||[];
 // 缓存里有效场次不足七场时，才补查最近40场；不为弹窗增加固定扫描请求量。
 if(recentSeven(teamId,rows,mode,kickoff).length<7&&!app.expandedHistory.has(teamId)){
  app.expandedHistory.add(teamId);
  try{const j=await api('fixtures',{team:teamId,last:40});
   const received=j.response||[];
   if(received.length){rows=received;app.histories.set(teamId,rows);}
  }catch(e){log(`最近40场补查失败(${teamId})：${e.message}`);}
 }
 return rows;
}
function recentTeamHTML(name,teamId,fixtures,mode,f){
 const rows=recentSeven(teamId,fixtures,mode,f.fixture.date),standing=recentStandingItem(f,teamId);
 const group=standing?.group?` · ${esc(standing.group)}`:'';
 const leagueRank=standing?`积分排名 联赛/阶段 #${esc(standing.rank??'—')} · ${esc(standing.points??'—')}分${group}`:'积分排名 暂无可核实数据（该赛事可能没有积分榜）';
 const win=rows.filter(x=>x.result==='win').length,draw=rows.filter(x=>x.result==='draw').length,loss=rows.filter(x=>x.result==='loss').length;
 const nh=rows.filter(x=>x.home).length;
 const marks={win:'胜',draw:'平',loss:'负'};
 const games=rows.length?rows.map(r=>`<div class="recentMatch"><span class="recentDate">${esc(recentDate(r.date))}</span><span class="venueTag ${r.home?'home':'away'}">${r.home?'主场':'客场'}</span><span class="recentOpponent">${esc(r.opponent)}</span><span class="recentScore">${r.gf}-${r.ga}</span><span class="recentOutcome ${r.result}">${marks[r.result]}</span></div>`).join(''):'<p class="recentSummary">暂无该队已结束且提供有效比分的比赛记录。</p>';
 return `<section class="recentTeam"><div class="recentName">${esc(name)}</div><div class="recentStanding">${leagueRank}</div><p class="recentSummary">最近${rows.length}/7场${mode==='half'?'半场':'全场'}：${win}胜 ${draw}平 ${loss}负 · 主场${nh} / 客场${rows.length-nh}</p>${games}</section>`;
}
function closeRecent(){
 app.recentToken++;
 recentOverlay.classList.remove('show');recentOverlay.setAttribute('aria-hidden','true');document.body.classList.remove('recentLocked');
 if(recentTrigger?.isConnected)recentTrigger.focus();
}
async function openRecent(fixtureId,mode,button){
 const x=app.ranked.find(item=>Number(item.f.fixture.id)===Number(fixtureId));if(!x)return;
 if(mode!=='half'&&mode!=='full')return;
 const f=x.f,token=++app.recentToken;
 recentTrigger=button;
 el('recentHeading').textContent=`积分排名 · 双方最近7场${mode==='half'?'半场':'全场'}结果`;
 recentOverlay.classList.add('show');recentOverlay.setAttribute('aria-hidden','false');document.body.classList.add('recentLocked');
 el('recentPanel').scrollTop=0;el('recentClose').focus();
 el('recentContent').innerHTML=`<p class="recentSub">${esc(f.teams.home.name)} vs ${esc(f.teams.away.name)} · 正在读取数据…</p>`;
 try{
  app.key=getKey();
  const homeId=Number(f.teams.home.id),awayId=Number(f.teams.away.id);
  const jobs=await Promise.allSettled([loadRecentHistory(homeId,mode,f.fixture.date),loadRecentHistory(awayId,mode,f.fixture.date),loadRecentStandings(f)]);
  if(token!==app.recentToken)return;
  const hr=jobs[0].status==='fulfilled'?jobs[0].value:app.histories.get(homeId)||[];
  const ar=jobs[1].status==='fulfilled'?jobs[1].value:app.histories.get(awayId)||[];
  const errors=jobs.slice(0,2).filter(x=>x.status==='rejected').map(x=>String(x.reason?.message||'历史数据加载失败'));
  const lk=f.league||{};
  const sub=`${esc(lk.name||'本场赛事')} · 赛季 ${esc(lk.season??'—')} · ${mode==='half'?'上半场45分钟比分':'全场结束比分'}`;
  el('recentContent').innerHTML=`<p class="recentSub">${sub}</p>`+recentTeamHTML(f.teams.home.name,homeId,hr,mode,f)+recentTeamHTML(f.teams.away.name,awayId,ar,mode,f)
   +(errors.length?`<div class="risk">部分历史请求失败：${esc(errors.join('；'))}</div>`:'')
   +`<div class="recentExplanation">蓝色＝该队历史主场，橙色＝该队历史客场；比分按该队进球–失球排列，胜平负只计${mode==='half'?'半场':'全场'}。最近7场取本场开赛前已完赛的跨赛事记录，不把全场结果作为上半场比分推荐依据。积分排名来自本场所属联赛／赛季的官方积分榜（若分组则为组内名次），与跨赛事的近7场统计口径不同；暂无数据时不推算。</div>`;
 }catch(e){if(token===app.recentToken)el('recentContent').innerHTML=`<p class="risk">读取失败：${esc(e.message)}</p>`;}
}
document.addEventListener('click',e=>{
 const b=e.target.closest?.('button[data-recent][data-fixture]');
 if(b)openRecent(b.dataset.fixture,b.dataset.recent,b);
});
el('recentClose').addEventListener('click',closeRecent);
recentOverlay.addEventListener('click',e=>{if(e.target===recentOverlay)closeRecent()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&recentOverlay.classList.contains('show'))closeRecent()});

const aiOverlay=el('aiOverlay');
let aiTrigger=null;
function closeAI(){
 app.aiToken++;
 aiOverlay.classList.remove('show');aiOverlay.setAttribute('aria-hidden','true');document.body.classList.remove('recentLocked');
 if(aiTrigger?.isConnected)aiTrigger.focus();
}
function outcomeWord(v){return v==='win'?'胜':v==='loss'?'负':'平'}
function scoreLineList(rows){return rows.map(r=>`${recentDate(r.date)} ${r.home?'主':'客'} vs ${r.opponent} ${r.gf}-${r.ga} ${outcomeWord(r.result)}`)}
function standingText(f,teamId){const s=recentStandingItem(f,teamId);if(!s)return '暂无积分排名';return `联赛/阶段第${s.rank??'—'}，${s.points??'—'}分${s.group?`，组别 ${s.group}`:''}`;}
function compactHistorySummary(side,label){return {label,recentSamples:side.n,venueSamples:side.venueN,weightedFor:Number(money(side.scored)),weightedAgainst:Number(money(side.conceded)),venueFor:Number(money(side.venueScored)),venueAgainst:Number(money(side.venueConceded)),attack:Number(money(side.attack)),defense:Number(money(side.defense)),blankHalves:side.blank,leadHalves:side.lead,behindHalves:side.behind,zeroFor:side.zeroFor,zeroAgainst:side.zeroAgainst,lastFiveFor:Number(money(side.lastFiveFor)),lastFiveAgainst:Number(money(side.lastFiveAgainst))};}
function marketSnapshot(x){
 const refs=referenceSet.map(s=>{const r=x.refs?.[s];return {score:s,odd:r?.quote?.odd?Number(money(r.quote.odd)):null,bookmaker:r?.quote?.bookmaker||null,modelProbability:r?.probability?Number((r.probability*100).toFixed(1)):null};});
 const ht1x2=x.markets?.ht?{bookmaker:x.markets.ht.bookmaker,home:Number((x.markets.ht.prob.home*100).toFixed(1)),draw:Number((x.markets.ht.prob.draw*100).toFixed(1)),away:Number((x.markets.ht.prob.away*100).toFixed(1)),odds:x.markets.ht.odds}:null;
 const htTotals=(x.markets?.htTotals||[]).map(t=>({line:t.line,bookmaker:t.bookmaker,probOver:Number((t.probOver*100).toFixed(1)),odds:t.odds}));
 return {ht1x2,htTotals,referenceScores:refs};
}
function buildAIPayload(x,homeHalf,awayHalf){
 const f=x.f;
 return {
  fixtureId:Number(f.fixture.id),
  match:`${f.teams.home.name} vs ${f.teams.away.name}`,
  kickoff:f.fixture.date,
  league:`${f.league?.country||''} · ${f.league?.name||''}`.trim(),
  currentScannerGrade:x.verdict.grade,
  scannerPrimaryScore:x.main.score,scannerBackupScore:x.backup?.score||null,scannerPair:x.backup?`${x.main.score} / ${x.backup.score}`:'PASS',pairMetrics:x.pair||null,
  scannerPrimaryProbability:Number((x.main.probability*100).toFixed(1)),
  scannerReason:x.main.reason,
  scannerRisk:x.verdict.reason,
  standings:{home:standingText(f,f.teams.home.id),away:standingText(f,f.teams.away.id)},
  halftimeHistory:{homeSummary:compactHistorySummary(x.h,'home'),awaySummary:compactHistorySummary(x.a,'away'),homeRecent7:scoreLineList(homeHalf),awayRecent7:scoreLineList(awayHalf)},
  market:marketSnapshot(x),
  crossEvidence:x.evidence?.context||[],
  targetCombos:['0-0 / 1-0','1-0 / 0-0','0-0 / 2-0','1-0 / 2-0','1-0 / 1-1','PASS']
 };
}
function extractJsonText(content){
 if(Array.isArray(content))return content.map(p=>typeof p==='string'?p:(p?.text||p?.content||'')).join('');
 return typeof content==='string'?content:String(content||'');
}
function cleanJsonBlock(text){const s=String(text||'').trim();const m=s.match(/\\{[\s\S]*\\}$/);return m?m[0]:s.replace(/^```json\s*/i,'').replace(/```$/,'').trim();}
// Native Android transport avoids WebView cross-origin restrictions; browser fallback remains supported.
let aiSequence=0;
const aiJobs=new Map();
window.HTAI={onReply(id,ok,raw){const job=aiJobs.get(String(id));if(!job)return;aiJobs.delete(String(id));clearTimeout(job.timer);if(ok){try{job.resolve(JSON.parse(raw));}catch(e){job.reject(Error('OpenAI响应JSON解析失败'));}}else{job.reject(Error(String(raw||'OpenAI请求失败').slice(0,230)));}}};
async function requestAICompletion(body,key){
 if(window.AndroidAI&&typeof window.AndroidAI.request==='function'){
  return new Promise((resolve,reject)=>{const id=String(++aiSequence);
   const timer=setTimeout(()=>{aiJobs.delete(id);reject(Error('OpenAI请求超时'));},65000);
   aiJobs.set(id,{resolve,reject,timer});
   try{window.AndroidAI.request(id,key,JSON.stringify(body));}catch(e){clearTimeout(timer);aiJobs.delete(id);reject(e);}
  });
 }
 const resp=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify(body)});
 const raw=await resp.text();let json;try{json=JSON.parse(raw)}catch(e){throw Error('OpenAI返回非JSON：'+raw.slice(0,120));}
 if(!resp.ok)throw Error('OpenAI HTTP '+resp.status+'：'+JSON.stringify(json.error?.message||json).slice(0,180));
 return json;
}
async function requestAIAnalysis(payload){
 const cfg=getOpenAIConfig(true);
 const system='你是半场主队低比分交叉审计员。0-0和1-0只能在真实概率位居前两名时作为主比分，2-0/1-1为次选。0-0真实Bet365半场比分赔率≥3，其余推荐比分≥4。独立核查最近比赛、同主客场、半场1X2、半场大小球和正确比分赔率与实际排序的关系。禁止编造数据、实时xG或提前结算，不能因低赔率假设概率或升级C/PASS。';
 const user=`请只输出JSON对象：decision,best_combo,primary_score,confidence,summary,reasons,risks,data_gaps。decision=PASS/可关注，best_combo只能scannerPair或PASS，primary_score只能scannerPrimaryScore或PASS，confidence=低/中/高。检查0-0/1-0是否真实领先、2-0/1-1是否居次以及主队优势、其他比分风险、报价门槛和价值，指出最可能失效的证据。不可升级当前评级。真实数据：\n${JSON.stringify(payload,null,2)}`;
 const body={model:cfg.model,messages:[{role:'system',content:system},{role:'user',content:user}],temperature:0.2,response_format:{type:'json_object'}};
 const json=await requestAICompletion(body,cfg.key);
 const content=extractJsonText(json.choices?.[0]?.message?.content||'');
 let parsed;try{parsed=JSON.parse(cleanJsonBlock(content));}catch(e){throw Error('AI 返回内容不是有效 JSON：'+content.slice(0,280));}
 if(!['PASS','可关注'].includes(parsed.decision)||!['PASS',payload.scannerPair].includes(parsed.best_combo)||!['PASS',payload.scannerPrimaryScore].includes(parsed.primary_score))throw Error('AI返回了未允许的比分组合/主比分，已拒绝');
 return {parsed,raw:content,model:json.model||cfg.model};
}
function renderAIResult(payload,result,model){
 const p=result||{};
 const reasons=(p.reasons||[]).map(x=>`<li>${esc(x)}</li>`).join('')||'<li>无</li>';
 const risks=(p.risks||[]).map(x=>`<li>${esc(x)}</li>`).join('')||'<li>无</li>';
 const gaps=(p.data_gaps||[]).map(x=>`<li>${esc(x)}</li>`).join('')||'<li>无</li>';
 const tags=(payload.crossEvidence||[]).map(x=>`<span class="aiTag">${esc(x)}</span>`).join('');
 return `<div class="aiNote">先看 PASS。独立历史模型的估计概率未经历史回测校准，不能把 AI 结论当作真实盈利率；本模块只研究决策，不会下单。</div>
 <div class="aiCard"><h4>${esc(payload.match)}</h4><div class="small">${esc(payload.league)} · 开赛 ${esc(hm(payload.kickoff))} · Fixture ID ${esc(payload.fixtureId)}</div><div class="aiGrid"><div class="aiKpi"><b>${esc(p.best_combo||'PASS')}</b><span>AI 对照比分组合</span></div><div class="aiKpi"><b>${esc(p.primary_score||'PASS')}</b><span>AI 主看比分</span></div><div class="aiKpi"><b>${esc(p.decision||'PASS')}</b><span>AI 结论</span></div><div class="aiKpi"><b>${esc(p.confidence||'低')}</b><span>确定性</span></div></div><div class="aiExplain">${esc(p.summary||'')}</div><div class="aiSectionTitle">核心理由</div><ul class="aiList">${reasons}</ul><div class="aiSectionTitle">主要风险</div><ul class="aiList">${risks}</ul><div class="aiSectionTitle">数据缺口</div><ul class="aiList">${gaps}</ul></div>
 <div class="aiCard"><h4>本地扫描器原始依据</h4><div class="small">当前扫描评级 ${esc(payload.currentScannerGrade)} · 主比分 ${esc(payload.scannerPrimaryScore)} · 模型概率 ${esc(payload.scannerPrimaryProbability)}%</div><div class="aiExplain">${esc(payload.scannerReason)}</div><div class="aiSectionTitle">交叉盘口提示</div>${tags||'<span class="aiTag">暂无</span>'}<div class="aiSectionTitle">目标比分价格对照</div><div class="aiRaw">${esc(JSON.stringify(payload.market.referenceScores,null,2))}</div><div class="aiSectionTitle">半场胜平负与大小球</div><div class="aiRaw">${esc(JSON.stringify({ht1x2:payload.market.ht1x2,htTotals:payload.market.htTotals},null,2))}</div><div class="aiSectionTitle">双方上半场近期状态与积分排名</div><div class="aiRaw">${esc(JSON.stringify({standings:payload.standings,halftimeHistory:payload.halftimeHistory},null,2))}</div><div class="small">OpenAI 模型：${esc(model||'未知')}</div></div>`;
}
async function openAIAnalysis(fixtureId,button){
 const x=app.ranked.find(item=>Number(item.f.fixture.id)===Number(fixtureId));if(!x)return;
 const token=++app.aiToken;aiTrigger=button;
 aiOverlay.classList.add('show');aiOverlay.setAttribute('aria-hidden','false');document.body.classList.add('recentLocked');
 el('aiPanel').scrollTop=0;el('aiClose').focus();
 el('aiHeading').textContent=`AI 分析 · ${x.f.teams.home.name} vs ${x.f.teams.away.name}`;
 el('aiContent').innerHTML='<p class="aiLoading">正在读取本场历史、积分排名与盘口，再调用 AI 分析…</p>';
 try{
  app.key=getKey();
  const homeId=Number(x.f.teams.home.id),awayId=Number(x.f.teams.away.id);
  const jobs=await Promise.allSettled([loadRecentHistory(homeId,'half',x.f.fixture.date),loadRecentHistory(awayId,'half',x.f.fixture.date),loadRecentStandings(x.f)]);
  if(token!==app.aiToken)return;
  const homeRows=jobs[0].status==='fulfilled'?jobs[0].value:app.histories.get(homeId)||[];
  const awayRows=jobs[1].status==='fulfilled'?jobs[1].value:app.histories.get(awayId)||[];
  const homeHalf=recentSeven(homeId,homeRows,'half',x.f.fixture.date);
  const awayHalf=recentSeven(awayId,awayRows,'half',x.f.fixture.date);
  const payload=buildAIPayload(x,homeHalf,awayHalf);
  el('aiContent').innerHTML='<p class="aiLoading">已整理真实数据，正在向 OpenAI 请求分析…</p>';
  const ai=await requestAIAnalysis(payload);
  if(token!==app.aiToken)return;
  el('aiContent').innerHTML=renderAIResult(payload,ai.parsed,ai.model);
 }catch(e){if(token===app.aiToken)el('aiContent').innerHTML=`<div class="aiError">AI 分析失败：${esc(e.message)}</div>`;}
}
document.addEventListener('click',e=>{const b=e.target.closest?.('button[data-ai][data-fixture]');if(b)openAIAnalysis(b.dataset.fixture,b);});
el('aiClose').addEventListener('click',closeAI);
aiOverlay.addEventListener('click',e=>{if(e.target===aiOverlay)closeAI()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&aiOverlay.classList.contains('show'))closeAI()});

// Transparent, local-only longitudinal validation. No API keys enter snapshots.
const AUDIT_STORE='ht-home-advantage-home-low-backtest-v1.1'; // Separate strategy test data: never mix prior backtests.
function loadAudit(){
 try{const rows=JSON.parse(localStorage.getItem(AUDIT_STORE)||'[]');return Array.isArray(rows)?rows.filter(r=>r&&Number.isSafeInteger(r.fixtureId)):[]}
 catch(err){log('复盘本机记录无法读取：'+err.message);return []}
}
function storeAudit(rows){
 try{localStorage.setItem(AUDIT_STORE,JSON.stringify(rows.slice(-1000)));return true}
 catch(err){log('复盘记录保存失败（本机空间可能不足）：'+err.message);out('复盘记录无法保存，请导出 CSV 后检查本机存储。');return false}
}
function saveScanSnapshots(matches){
 const rows=loadAudit(),existing=new Set(rows.map(r=>r.fixtureId)),now=new Date().toISOString();let added=0;
 for(const x of matches){
  const f=x.f,q=x.main.quote,id=Number(f.fixture.id);
  if(existing.has(id)||!scorePriceOK(x.main,MIN_ODD))continue;
  const outcome=footballOutcome(x.prior.lh,x.prior.la);
  rows.push({fixtureId:id,kickoff:String(f.fixture.date),league:String(f.league?.name||''),
   home:String(f.teams.home.name),away:String(f.teams.away.name),score:x.main.score,
   odd:q.odd,backupScore:x.backup?.score||null,backupOdd:x.backup?.quote?.odd||null,pairCoverage:x.pair?.coveredProbability??null,pairBreakeven:x.pair?.breakeven??null,zeroRisk:x.evidence.zeroRisk,source:'Bet365',marketUpdatedAt:q.updatedAt||null,capturedAt:now,
   p:Number(x.main.probability.toFixed(5)),homeWinP:Number(outcome.home.toFixed(5)),
   theoreticalEV:Number((x.main.probability*q.odd-1).toFixed(4)),grade:x.verdict.grade,
   ai:x.verdict.aiScreen?.decision||'无有效AI复核',model:'home-low-score-v1.1',
   actualHT:null,hit:null,pairHit:null,settledAt:null,lastChecked:null});
  existing.add(id);added++;
 }
 if(added){rows.sort((a,b)=>new Date(a.capturedAt)-new Date(b.capturedAt));storeAudit(rows);}
 renderReview();
 if(added)log(`保存${added}场独立历史概率+Bet365赔率赛前快照，累计记录${rows.length}场`);
}
function calculateAudit(rows){
 const completed=rows.filter(r=>r.actualHT!=null),qualified=completed.filter(r=>['A','B'].includes(r.grade));
 const makeStats=items=>{
  const n=items.length,hits=items.filter(r=>r.hit===true).length;
  const payout=items.reduce((v,r)=>v+(r.hit?r.odd:0),0);
  const brier=items.reduce((v,r)=>v+(r.p-(r.hit?1:0))**2,0);
  return {n,hits,hitRate:n?hits/n:null,roi:n?payout/n-1:null,brier:n?brier/n:null};
 };
 const pairRows=qualified.filter(r=>r.backupScore&&r.backupOdd>1&&r.odd>1&&r.actualHT!=null);
 const pairHits=pairRows.filter(r=>r.actualHT===r.score||r.actualHT===r.backupScore).length;
 const pairPayout=pairRows.reduce((v,r)=>{
  const isHit=r.actualHT===r.score||r.actualHT===r.backupScore;
  return v+(isHit?1/(1/r.odd+1/r.backupOdd):0);
 },0);
 const pairBrier=pairRows.reduce((v,r)=>v+(Number(r.pairCoverage)-(r.actualHT===r.score||r.actualHT===r.backupScore?1:0))**2,0);
 return {all:makeStats(completed),qualified:makeStats(qualified),byScore:Object.fromEntries(targetScoreSet.map(score=>[score,makeStats(qualified.filter(r=>r.score===score))])),
  pair:{n:pairRows.length,hits:pairHits,hitRate:pairRows.length?pairHits/pairRows.length:null,roi:pairRows.length?pairPayout/pairRows.length-1:null,brier:pairRows.length?pairBrier/pairRows.length:null}};
}
function renderReview(){
 const rows=loadAudit(),pending=rows.filter(r=>r.actualHT==null).length,stats=calculateAudit(rows);
 const signedPct=v=>v==null?'—':`${v>=0?'+':''}${(100*v).toFixed(1)}%`;
 const quality=stats.qualified;
 el('reviewSummary').textContent=`本机已保存 ${rows.length} 场新引擎赛前快照 · 已核对 ${stats.all.n} 场 · 待核对 ${pending} 场。\nA/B主比分历史样本 ${quality.n} 场；主比分命中 ${quality.hits} 场（${quality.hitRate==null?'—':pct(quality.hitRate)}），每场等额1单位模拟ROI ${signedPct(quality.roi)}。\nA/B双比分样本 ${stats.pair.n} 场，组合命中 ${stats.pair.hits} 场（${stats.pair.hitRate==null?'—':pct(stats.pair.hitRate)}），等额返还模拟ROI ${signedPct(stats.pair.roi)}，组合Brier ${stats.pair.brier==null?'—':stats.pair.brier.toFixed(3)}。${stats.pair.n<50?'样本不足50场：只展示，不给盈利结论。':'达到50场仍应进行跨赛季独立验证。'}以上都是持有到半场结算的模拟，不是提前结算实得收益。`;
 el('reviewDetails').innerHTML=targetScoreSet.map(score=>{
  const v=stats.byScore[score];
  return `<span class="pill ${v.n<30?'cgrade':''}">${score}：${v.n}场｜命中${v.hits}｜模拟ROI ${signedPct(v.roi)}${v.n<30?'（样本不足）':''}</span>`;
 }).join(' ');
 el('exportReview').disabled=!rows.length;
}
async function refreshArchive(maxChecks=12){
 if(app.reviewBusy)return;
 const now=Date.now(),rows=loadAudit();let checked=0,settled=0,errors=0;
 const eligible=rows.filter(r=>r.actualHT==null&&Number.isFinite(Date.parse(r.kickoff))&&
  now-Date.parse(r.kickoff)>115*60000&&(!r.lastChecked||now-Date.parse(r.lastChecked)>20*60*60*1000))
  .sort((a,b)=>Date.parse(a.kickoff)-Date.parse(b.kickoff)).slice(0,maxChecks);
 if(!eligible.length){renderReview();return;}
 app.reviewBusy=true;el('refreshReview').disabled=true;
 try{
  for(const item of eligible){
   if(app.cancel)break;
   try{
    const result=await api('fixtures',{id:item.fixtureId});checked++;
    const match=(result.response||[]).find(f=>Number(f.fixture?.id)===item.fixtureId);
    const half=match?numericHT(match):null;
    if(half){item.actualHT=half.join('-');item.hit=item.actualHT===item.score;item.pairHit=item.hit||(item.backupScore!=null&&item.actualHT===item.backupScore);item.settledAt=new Date().toISOString();settled++;}
    else log(`复盘 ${item.fixtureId} 暂无可确认的半场最终比分，仍保留待核验`);
   }catch(e){errors++;log(`复盘 ${item.fixtureId} 请求失败：${e.message}`)}
   item.lastChecked=new Date().toISOString();
  }
  storeAudit(rows);renderReview();
  log(`复盘完成：请求${checked}场，已核对${settled}场，错误${errors}场`);
 }finally{app.reviewBusy=false;el('refreshReview').disabled=false}
}
function exportAuditCSV(){
 const rows=loadAudit();if(!rows.length)throw Error('暂无复盘记录');
 const cols=['fixtureId','kickoff','league','home','away','score','odd','backupScore','backupOdd','pairCoverage','pairBreakeven','zeroRisk','source','marketUpdatedAt','capturedAt','p','homeWinP','theoreticalEV','grade','ai','model','actualHT','hit','pairHit','settledAt'];
 // Escape cells safely: prevent spreadsheet formula interpretation for external team/league names.
 const safe=v=>{let s=String(v==null?'':v);if(/^[\s]*[=+@\-]/.test(s)&&!/^-[0-9.]+$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
 const csv='\ufeff'+[cols.join(','),...rows.map(r=>cols.map(k=>safe(r[k])).join(','))].join('\r\n');
 downloadBlob(new Blob([csv],{type:'text/csv;charset=utf-8'}),`HT半场赔率复盘_${ymd(Date.now())}.csv`);
}
el('refreshReview').addEventListener('click',async()=>{
 if(app.running){out('扫描正在进行，完成后再刷新复盘。');return;}
 try{app.key=getKey();await refreshArchive(20)}catch(e){out('复盘失败：'+e.message)}
});
el('exportReview').addEventListener('click',()=>{try{exportAuditCSV()}catch(e){out('导出失败：'+e.message)}});
renderReview();

function selectedMatches(){return app.ranked.filter(x=>app.selected.has(`${x.f.fixture.id}:${x.main.score}`));}

function groupSelected(){let groups=new Map();for(const x of selectedMatches()){const timestamp=Math.floor(new Date(x.f.fixture.date).getTime()/60000)*60000;if(!groups.has(timestamp))groups.set(timestamp,[]);groups.get(timestamp).push(x)}return [...groups.entries()].sort((a,b)=>a[0]-b[0]);}
function renderGroups(){
 const rows=groupSelected();
 el('selectedNum').textContent=String(app.selected.size);
 el('timeNum').textContent=String(rows.length);
 el('png').disabled=!rows.length;
 const target=el('groups');
 if(!rows.length){target.innerHTML='<div class="empty">尚未勾选比赛。请勾选需要生成截图的比赛；C/PASS仅作为观察，不变更评级。</div>';return;}
 target.innerHTML=rows.map(([ts,arr])=>`<div class="note"><strong>🕒 ${esc(ymd(ts))} ${hm(ts)}</strong>　${arr.length}场比赛，合并为1组<div class="small">${arr.map(x=>`${esc(x.f.teams.home.name)} vs ${esc(x.f.teams.away.name)} [主${esc(x.main.score)}${x.backup?' + 备'+esc(x.backup.score):''}]`).join('　 ·　 ')}</div><div class="small">勾选这些比赛后，点击页面顶部“统一生成已勾选比赛PNG”。</div></div>`).join('');
}

function downloadBlob(blob,name){
 // Android WebView cannot directly download blob: links. Save native files through a local bridge.
 if(window.AndroidFile && typeof window.AndroidFile.saveBase64==='function'){
   const reader=new FileReader();
   reader.onload=()=>{
     try{
       const raw=String(reader.result||'');
       const comma=raw.indexOf(',');
       if(comma<0) throw Error('图片数据转换失败');
       window.AndroidFile.saveBase64(String(name),String(blob.type||'application/octet-stream'),raw.slice(comma+1));
     }catch(err){alert('保存文件失败：'+err.message)}
   };
   reader.onerror=()=>alert('无法读取生成的文件');
   reader.readAsDataURL(blob);
   return;
 }
 const link=document.createElement('a');
 const url=URL.createObjectURL(blob);
 link.href=url; link.download=name;document.body.appendChild(link);link.click();link.remove();
 setTimeout(()=>URL.revokeObjectURL(url),15000);
}
function localTitle(ts){return `${ymd(ts)} ${hm(ts)}`}
function getImage(onlyMatches=null){
 // PNG transfer format for HT LIVE MONITOR: a separate OCR-friendly card for
 // every selected API fixture. Do not draw reminder times, odds or predictions.
 // Source fixture IDs come straight from API-FOOTBALL; no synthesized IDs.
 const gs=onlyMatches ? onlyMatches.map(x=>[Math.floor(new Date(x.f.fixture.date).getTime()/60000)*60000,[x]]) : groupSelected();
 if(!gs.length)throw Error('请先勾选至少一场比赛，再生成图片');
 const games=gs.flatMap(([ts,arr])=>arr.map(x=>({
  ts,home:String(x.f.teams.home.name||''),away:String(x.f.teams.away.name||''),
  id:String(x.f.fixture.id)
 })));
 const W=1160,margin=52,cardWidth=W-margin*2,textWidth=cardWidth-80;
 const canvas=document.createElement('canvas');
 const c=canvas.getContext('2d');
 const font=(size,weight=700)=>`${weight} ${size}px 'Arial','Microsoft YaHei','PingFang SC',sans-serif`;
 function fitLines(text){
  let size=39;
  while(size>30){c.font=font(size,750);if(c.measureText(text).width<=textWidth)break;size-=1}
  c.font=font(size,750);
  if(c.measureText(text).width<=textWidth)return {size,lines:[text]};
  const words=String(text).split(/(?<=\s)|(?=\s)/).filter(Boolean);
  const lines=[];let current='';
  for(const word of words){
   if(c.measureText(current+word).width>textWidth&&current){lines.push(current.trim());current=word.trimStart()}
   else current+=word;
  }
  if(current.trim())lines.push(current.trim());
  // A team name without spaces (e.g. Chinese names) still must fit the image.
  const safe=[];
  for(const line of lines){
   let segment='';
   for(const char of line){if(c.measureText(segment+char).width>textWidth&&segment){safe.push(segment);segment=''}segment+=char}
   if(segment)safe.push(segment);
  }
  return {size,lines:safe};
 }
 const cards=games.map(game=>{
  const names=fitLines(`${game.home} vs ${game.away}`);
  return {...game,names,height:188+Math.max(0,names.lines.length-1)*51};
 });
 const imageHeight=40+cards.reduce((sum,card)=>sum+card.height+18,0)+22;
 if(imageHeight>30000)throw Error('比赛太多，图片高度超过安全限制，请减少勾选数量分批导出。');
 canvas.width=W;canvas.height=imageHeight;
 c.textBaseline='top';
 c.fillStyle='#06131C';c.fillRect(0,0,W,imageHeight);
 const draw=(text,x,y,size,color,weight=700)=>{c.font=font(size,weight);c.fillStyle=color;c.fillText(text,x,y)};
 let y=40;
 for(const game of cards){
  c.fillStyle='#102B36';c.fillRect(margin,y,cardWidth,game.height);
  c.fillStyle='#57E5CE';c.fillRect(margin,y,7,game.height);
  const x=margin+40;
  // One green kickoff line + white team names. Always the actual kickoff,
  // formatted in the same Argentina timezone as the scanner.
  draw(`${ymd(game.ts)} ${hm(game.ts)} 开赛`,x,y+20,44,'#A6FFE6',800);
  let lineY=y+87;
  for(const line of game.names.lines){draw(line,x,lineY,game.names.size,'#FFFFFF',750);lineY+=51}
  draw(`Fixture ID: ${game.id}`,x,lineY+4,29,'#FFFFFF',700);
  y+=game.height+18;
 }
 return canvas;
}
async function exportPNG(onlyId=null){
 const match=onlyId==null?null:app.ranked.find(x=>Number(x.f.fixture.id)===Number(onlyId));
 if(onlyId!=null&&!match)throw Error('无法找到该场比赛，请重新扫描。');
 const canvas=getImage(match?[match]:null);
 const blob=await new Promise(r=>canvas.toBlob(r,'image/png'));
 if(!blob)throw Error('PNG 图片生成失败');
 const name=match?`HT单场_${ymd(match.f.fixture.date)}_${match.f.fixture.id}.png`:`上半场比赛列表_${el('day').value}.png`;
 downloadBlob(blob,name);
}

function guard(fn){return async()=>{try{await fn()}catch(e){out(`操作失败：${e.message}`);log(`错误：${e.message}`);renderProgress(0)}finally{setRunning(false)}}}
el('test').addEventListener('click',guard(async()=>{app.key=getKey();setRunning(true);const j=await api('status');out(`连接成功：账号 ${j.response?.account?.firstname||'已验证'}；计划 ${j.response?.subscription?.plan||'未知'}；今日请求已用 ${j.response?.requests?.current??'—'} / ${j.response?.requests?.limit_day??'—'}。`);log('API-FOOTBALL Key验证成功。')}));
el('scan').addEventListener('click',guard(async()=>{setRunning(true);await scan()}));el('stop').addEventListener('click',()=>{app.cancel=true;el('stop').disabled=true;out('正在停止：已发出的请求不能撤回。')});
el('pickTop').addEventListener('click',()=>{app.selected.clear();for(const x of app.ranked.filter(x=>['A','B'].includes(x.verdict.grade)).slice(0,10))app.selected.add(x.f.fixture.id+':'+x.main.score);renderResults();renderGroups()});el('clear').addEventListener('click',()=>{app.selected.clear();renderResults();renderGroups()});
el('png').addEventListener('click',async()=>{try{await exportPNG()}catch(e){out('图片生成失败：'+e.message);log('PNG失败：'+e.message)}});
document.addEventListener('click',async e=>{const btn=e.target.closest?.('button[data-onepng]');if(!btn)return;
 btn.disabled=true;try{await exportPNG(btn.dataset.onepng)}catch(err){out('单场生成失败：'+err.message);log('单场PNG错误：'+err.message)}finally{btn.disabled=false}
});

})();